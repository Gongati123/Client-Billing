import React from "react";
import { Link, NavLink, Outlet } from "react-router-dom";
import {
  LayoutDashboard,
  Users,
  Briefcase,
  FileText,
  BarChart3,
} from "lucide-react";
import {
  FaBell,
  FaSignOutAlt,
  FaFolderOpen,
  FaUserTie,
} from "react-icons/fa";

const SuperAdminLayout = () => {
  const handleLogout = () => {
    alert("Logged out successfully!");
  };

  const menu = [
    { icon: <LayoutDashboard className="w-5 h-5" />, text: "Summary ", link: "/admin-dashboard/summary" },
    { icon: <Users className="w-5 h-5" />, text: "Clients", link: "/admin-dashboard/clients" },
    { icon: <Briefcase className="w-5 h-5" />, text: "Employees", link: "/admin-dashboard/employees" },
    { icon: <FaUserTie className="w-5 h-5" />, text: "Manager", link: "/admin-dashboard/managers" },
    { icon: <FaFolderOpen className="w-5 h-5" />, text: "Projects", link: "/admin-dashboard/projects" },
    { icon: <FileText className="w-5 h-5" />, text: "Invoices", link: "/admin-dashboard/invoices" },
    // { icon: <BarChart3 className="w-5 h-5" />, text: "Reports", link: "/admin-dashboard/reports" },
   

    
  ];

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <div className="w-64 bg-[#5c677d] text-white p-6">
        <h1 className="text-2xl font-bold mb-8 text-center">Dashboard</h1>

        <ul className="space-y-4">
          {menu.map((item, idx) => (
            <li key={idx}>
              <NavLink
                to={item.link}
                className={({ isActive }) =>
                  `flex items-center gap-3 p-2 rounded-lg transition ${
                    isActive
                      ? "bg-blue-600 text-white"
                      : "hover:bg-blue-200 hover:text-black"
                  }`
                }
              >
                {item.icon}
                <span>{item.text}</span>
              </NavLink>
            </li>
          ))}
        </ul>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col">
        {/* Navbar */}
        <div className="flex justify-between items-center bg-[#5c677d] shadow px-6 py-4">
          <h2 className="text-xl font-semibold text-white">Admin Dashboard</h2>

          <div className="flex items-center gap-6">
            {/* Notification */}
            {/* <Link
              to="notification"
              className="relative text-white hover:text-yellow-100 transition"
            >
              <FaBell size={22} />
              <span className="absolute -top-1 -right-1 bg-red-500 text-xs text-white px-1.5 rounded-full">
              </span>
            </Link> */}

            {/* Logout */}
            <Link
              to="/Login"
              onClick={handleLogout}
              className="flex items-center gap-2 text-white text-xl"
            >
              <FaSignOutAlt />
            </Link>

            {/* Profile Image */}
            <Link to ="profile">
            <img
              src="/Images/Me.jpeg"
              alt="Profile"
              className="w-8 h-8 rounded-full border-2 border-white"
            />
            
            </Link>
          </div>
        </div>

        {/* Nested pages go here */}
        <div className="p-6 flex-1 bg-gray-50">
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default SuperAdminLayout;
