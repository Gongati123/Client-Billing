


import React, { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { FaProjectDiagram, FaUsers, FaCheckCircle, FaSpinner, FaUserAlt } from "react-icons/fa";
import { Bell, User, LogOut } from "lucide-react";
import teamleadData from "./teamleadData.json";

// Map icons to actual components
const iconMap = {
  FaProjectDiagram: <FaProjectDiagram className="text-3xl" />,
  FaUsers: <FaUsers className="text-3xl" />,
  FaCheckCircle: <FaCheckCircle className="text-3xl" />,
  FaSpinner: <FaSpinner className="text-3xl animate-spin" />,
};

// Optional: gradient colors per card type
const gradientMap = {
  FaProjectDiagram: "from-blue-400 to-blue-600",
  FaUsers: "from-green-400 to-green-600",
  FaCheckCircle: "from-indigo-400 to-indigo-600",
  FaSpinner: "from-orange-400 to-orange-600",
};

export default function TeamleadDashboard() {
  const navigate = useNavigate();
  const location = useLocation();
  const [activeItem, setActiveItem] = useState(location.pathname);
  const [selectedView, setSelectedView] = useState("dashboard");

  const menuItems = [
    { id: "/TeamProjects", name: "Projects", icon: <FaProjectDiagram /> },
    { id: "/TeamEmployees", name: "Employees", icon: <FaUserAlt /> },
  ];

  const handleLogout = () => {
    // Clear authentication data if needed
    navigate("/login");
  };

  const renderContent = () => {
    switch (selectedView) {
      case "projects":
        return (
          <div>
            <h2 className="text-2xl font-bold mb-4 text-gray-800">Manage Projects</h2>
            <p className="text-gray-600">Here you can view, create, and manage projects.</p>
          </div>
        );
      case "resources":
        return (
          <div>
            <h2 className="text-2xl font-bold mb-4 text-gray-800">Assign Resources</h2>
            <p className="text-gray-600">Assign and manage resources for ongoing projects here.</p>
          </div>
        );
      default:
        return (
          <>
            <h2 className="text-2xl font-bold mb-6 text-gray-800">Teamlead Dashboard Overview</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {teamleadData.map((card, index) => {
                const gradient = gradientMap[card.icon] || "from-gray-400 to-gray-600";
                return (
                  <div
                    key={index}
                    className={`bg-gradient-to-r ${gradient} text-white p-8 rounded-2xl shadow-md hover:shadow-xl transform hover:scale-105 transition-all duration-300 flex items-center justify-between min-h-[120px]`}
                  >
                    <div>
                      <h3 className="text-base font-semibold">{card.title}</h3>
                      <p className="text-3xl font-bold mt-2">{card.value}</p>
                    </div>
                    <div>{iconMap[card.icon]}</div>
                  </div>
                );
              })}
            </div>
          </>
        );
    }
  };

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div className="w-64 bg-gray-800 text-white flex flex-col">
        <div className="p-6 text-xl font-bold border-b border-gray-700">Teamlead Dashboard</div>
        <nav className="flex-1 p-4 space-y-2">
          {menuItems.map((item) => (
            <Link
              to={item.id}
              key={item.id}
              className={`flex items-center w-full p-3 rounded-lg text-left hover:bg-gray-700 transition-colors ${
                activeItem === item.id ? "bg-gray-700" : ""
              }`}
              onClick={() => {
                setActiveItem(item.id);
                setSelectedView(item.id === "/Projects" ? "projects" : "resources");
              }}
            >
              <span className="mr-3 text-lg">{item.icon}</span>
              {item.name}
            </Link>
          ))}
        </nav>
        <div className="p-6 border-t border-gray-700">
          <button
            onClick={handleLogout}
            // className="w-full text-left p-3 rounded-lg hover:bg-gray-700 transition-colors"
          >
            
          </button>
        </div>
      </div>

      {/* Main content area */}
      <div className="flex-1 flex flex-col">
        {/* Navbar */}
        <nav className="bg-gray-800 shadow-md h-16 flex items-center justify-between px-6">
          {/* Left side - Page title */}
          <div className="flex-1 flex items-center">
            <span className="text-2xl font-bold text-white">{selectedView === "projects" ? "Projects" : selectedView === "resources" ? "Resources" : ""}</span>
          </div>

          {/* Right side - icons and logout */}
          <div className="flex items-center space-x-6">
            {/* <Link to="/notifications" className="relative text-yellow-400 hover:text-blue-600 transition">
              <Bell className="w-6 h-6" />
            </Link> */}
            <Link to="/TeamProfile" className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-full bg-blue-100 flex items-center justify-center">
                <User className="text-blue-700 w-5 h-5" />
              </div>
              <div className="text-white">
                <p className="text-sm font-semibold"></p>
                <p className="text-xs text-white"></p>
              </div>
            </Link>
            <button
              onClick={handleLogout}
              className="flex items-center gap-1 bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded transition"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </div>
        </nav>

        {/* Dashboard Content */}
        <div className="p-6 overflow-y-auto flex-1">{renderContent()}</div>
      </div>
    </div>
  );
}
