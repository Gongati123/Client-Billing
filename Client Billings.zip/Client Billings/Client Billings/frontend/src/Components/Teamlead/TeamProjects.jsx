
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import TeamprojectsData from "./TeamprojectsData.json";

export default function Projects() {
  const [projects, setProjects] = useState([]);
  const [newProject, setNewProject] = useState({
    name: "",
    billingRate: "",
    startDate: "",
    endDate: "",
  });

  const navigate = useNavigate();

  useEffect(() => {
    setProjects(TeamprojectsData);
  }, []);

  // ✅ Add new project
  const handleAddProject = () => {
    if (!newProject.name || !newProject.billingRate) return;

    const newEntry = {
      id: `P${projects.length + 101}`,
      ...newProject,
    };

    setProjects([...projects, newEntry]);
    setNewProject({ name: "", billingRate: "", startDate: "", endDate: "" });
  };

  return (
    <div className="p-6">

      <button
        onClick={() => navigate(-1)}
        className="mb-4 px-4 py-2 bg-green-400 text-gray-800 rounded hover:bg-gray-300 transition"
      >
        &larr; Back
      </button>

      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-semibold">Projects</h2>
      </div>

      {/* ➕ Add Project Form */}
      <div className="flex flex-col sm:flex-row gap-2 mb-6 flex-wrap">
        <input
          type="text"
          placeholder="Project Name"
          className="p-2 border rounded flex-1"
          value={newProject.name}
          onChange={(e) =>
            setNewProject({ ...newProject, name: e.target.value })
          }
        />
        <input
          type="text"
          placeholder="Billing Rate"
          className="p-2 border rounded flex-1"
          value={newProject.billingRate}
          onChange={(e) =>
            setNewProject({ ...newProject, billingRate: e.target.value })
          }
        />
        <input
          type="date"
          className="p-2 border rounded flex-1"
          value={newProject.startDate}
          onChange={(e) =>
            setNewProject({ ...newProject, startDate: e.target.value })
          }
        />
        <input
          type="date"
          className="p-2 border rounded flex-1"
          value={newProject.endDate}
          onChange={(e) =>
            setNewProject({ ...newProject, endDate: e.target.value })
          }
        />
        <button
          onClick={handleAddProject}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          + Add Project
        </button>
      </div>


      {/* 📋 Projects Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full bg-blue-400 border-gray-200 shadow-sm rounded-lg">
          <thead className="bg-orange-500">
            <tr>
              <th className="py-2 px-4 border-b">S.No</th>
              <th className="py-2 px-4 border-b">Project ID</th>
              <th className="py-2 px-4 border-b">Project Name</th>
              <th className="py-2 px-4 border-b">Billing Rate</th>
              <th className="py-2 px-4 border-b">Start Date</th>
              <th className="py-2 px-4 border-b">End Date</th>
            </tr>
          </thead>
          <tbody>
            {projects.map((project, index) => (
              <tr
                key={project.id}
                className="text-center border-b hover:bg-gray-50"
              >
                <td className="py-2 px-4">{index + 1}</td>
                <td className="py-2 px-4">{project.id}</td>
                <td className="py-2 px-4">{project.name}</td>
                <td className="py-2 px-4">{project.billingRate}</td>
                <td className="py-2 px-4">{project.startDate}</td>
                <td className="py-2 px-4">{project.endDate}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
