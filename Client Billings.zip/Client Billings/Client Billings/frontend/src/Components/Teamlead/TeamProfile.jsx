

import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Profile() {
  const [user, setUser] = useState({
    name: "Karthik",
    email: "karthik@example.com",
    role: "Team lead",
  });

  const [passwords, setPasswords] = useState({
    current: "",
    new: "",
    confirm: "",
  });

  const [editMode, setEditMode] = useState(false);
  const navigate = useNavigate();

  const handleProfileUpdate = () => {
    setEditMode(false);
    alert("Profile updated successfully!");
  };

  const handlePasswordChange = () => {
    if (passwords.new !== passwords.confirm) {
      alert("New password and confirm password do not match!");
      return;
    }
    setPasswords({ current: "", new: "", confirm: "" });
    alert("Password updated successfully!");
  };

  return (
    <div className="max-w-md mx-auto p-4 mt-10">
      {/* Back Button */}
      <button
        onClick={() => navigate(-1)}
        className="mb-4 px-4 py-2 bg-green-400 text-gray-800 rounded hover:bg-gray-300 transition"
      >
        &larr; Back
      </button>

      {/* Profile Box */}
      <div className="p-4 bg-violet-300 rounded-lg shadow-md">
        <h2 className="text-xl font-bold mb-4 text-gray-800 text-center">Profile</h2>

        {/* Profile Info */}
        <div className="mb-4">
          <h3 className="text-base font-semibold mb-1">User Information</h3>
          <div className="flex flex-col gap-3">
            <div>
              <label className="block text-gray-700 text-sm">Name:</label>
              {editMode ? (
                <input
                  type="text"
                  value={user.name}
                  onChange={(e) => setUser({ ...user, name: e.target.value })}
                  className="w-full p-1.5 border rounded text-sm"
                />
              ) : (
                <p className="text-gray-900 text-sm">{user.name}</p>
              )}
            </div>

            <div>
              <label className="block text-gray-700 text-sm">Email:</label>
              {editMode ? (
                <input
                  type="email"
                  value={user.email}
                  onChange={(e) => setUser({ ...user, email: e.target.value })}
                  className="w-full p-1.5 border rounded text-sm"
                />
              ) : (
                <p className="text-gray-900 text-sm">{user.email}</p>
              )}
            </div>

            <div>
              <label className="block text-gray-700 text-sm">Role:</label>
              <p className="text-gray-900 text-sm">{user.role}</p>
            </div>
          </div>

          <button
            onClick={editMode ? handleProfileUpdate : () => setEditMode(true)}
            className="mt-2 bg-blue-500 text-white px-3 py-1 rounded text-sm hover:bg-blue-600 transition"
          >
            {editMode ? "Save" : "Edit"}
          </button>
        </div>

        {/* Password Update */}
        <div>
          <h3 className="text-base font-semibold mb-1">Change Password</h3>
          <div className="flex flex-col gap-2">
            <input
              type="password"
              placeholder="Current Password"
              value={passwords.current}
              onChange={(e) => setPasswords({ ...passwords, current: e.target.value })}
              className="w-full p-1.5 border rounded text-sm"
            />
            <input
              type="password"
              placeholder="New Password"
              value={passwords.new}
              onChange={(e) => setPasswords({ ...passwords, new: e.target.value })}
              className="w-full p-1.5 border rounded text-sm"
            />
            <input
              type="password"
              placeholder="Confirm Password"
              value={passwords.confirm}
              onChange={(e) => setPasswords({ ...passwords, confirm: e.target.value })}
              className="w-full p-1.5 border rounded text-sm"
            />
            <button
              onClick={handlePasswordChange}
              className="bg-green-500 text-white px-3 py-1 rounded text-sm hover:bg-green-600 transition"
            >
              Update
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
