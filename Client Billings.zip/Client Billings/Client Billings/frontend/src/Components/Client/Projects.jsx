// import React, { useState, useEffect } from "react";
// import {
//   FaPlus,
//   FaEdit,
//   FaTrashAlt,
//   FaFolderOpen,
// } from "react-icons/fa";
// import { ToastContainer, toast } from "react-toastify";
// import "react-toastify/dist/ReactToastify.css";

// const Project = () => {
//   const [projects, setProjects] = useState([]);
//   const [editProjectId, setEditProjectId] = useState(null);
//   const [formData, setFormData] = useState({
//     projectId: "",
//     clientId: "",
//     projectName: "",
//     billingRate: "",
//     startDate: "",
//     endDate: "",
//   });
//   const [showModal, setShowModal] = useState(false);

//   // 🟢 Example placeholder for fetch
//   useEffect(() => {
//     // Example API fetch (commented out for now)
//     // fetch("http://localhost:8080/projects")
//     //   .then((res) => res.json())
//     //   .then((data) => setProjects(data))
//     //   .catch(() => toast.info("⚠️ Backend not reachable."));
//   }, []);

//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//   };

//   // ✏ Edit project
//   const handleEdit = (proj) => { 
//     setEditProjectId(proj.id);
//     setFormData(proj);
//     setShowModal(true);
//   };

//   // 💾 Save edited project
//   const handleSave = () => {
//     const updated = projects.map((p) =>
//       p.id === editProjectId ? { ...formData } : p
//     );
//     setProjects(updated);
//     setEditProjectId(null);
//     setShowModal(false);
//     toast.success("✅ Project updated successfully!");
//   };

//   // ➕ Add new project
//   const handleAddProject = (e) => {
//     e.preventDefault();
//     if (
//       !formData.projectId ||
//       !formData.clientId ||
//       !formData.projectName ||
//       !formData.billingRate ||
//       !formData.startDate ||
//       !formData.endDate
//     ) {
//       toast.warn("⚠ Please fill all required fields!");
//       return;
//     }

//     const newProject = { ...formData, id: Date.now() };
//     setProjects([...projects, newProject]);
//     setShowModal(false);
//     toast.success("✅ Project added successfully!");
//   };

//   // 🗑 Custom Delete Confirmation Toast
//   const confirmDelete = (id) => {
//     toast(
//       ({ closeToast }) => (
//         <div className="flex flex-col items-start">
//           <p className="font-semibold text-gray-800 mb-3">
//             🗑️ Are you sure you want to delete this project?
//           </p>
//           <div className="flex justify-end w-full gap-3">
//             <button
//               className="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700"
//               onClick={() => {
//                 setProjects(projects.filter((p) => p.id !== id));
//                 toast.dismiss();
//                 toast.info("✅ Project deleted successfully.");
//               }}
//             >
//               Yes, Delete
//             </button>
//             <button
//               className="bg-gray-300 text-gray-800 px-3 py-1 rounded hover:bg-gray-400"
//               onClick={closeToast}
//             >
//               Cancel
//             </button>
//           </div>
//         </div>
//       ),
//       {
//         position: "top-center",
//         autoClose: false,
//         closeOnClick: false,
//         draggable: false,
//         hideProgressBar: true,
//       }
//     );
//   };

//   return (
//     <div className="p-6 bg-gray-50 min-h-screen">
//       {/* Toast Notification Container */}
//       <ToastContainer
//         position="top-center"
//         autoClose={2500}
//         hideProgressBar={false}
//         newestOnTop={false}
//         closeOnClick
//         pauseOnHover
//         draggable
//         theme="colored"
//       />

//       <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
//         <FaFolderOpen /> Projects
//       </h2>

//       {/* Add Project Button */}
//       <div className="flex justify-end mb-4">
//         <button
//           onClick={() => {
//             setShowModal(true);
//             setEditProjectId(null);
//             setFormData({
//               projectId: "",
//               clientId: "",
//               projectName: "",
//               billingRate: "",
//               startDate: "",
//               endDate: "",
//             });
//           }}
//           className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition"
//         >
//           <FaPlus /> Add Project
//         </button>
//       </div>

//       {/* Projects Table */}
//       <div className="overflow-x-auto bg-white shadow-md rounded-xl">
//         <table className="min-w-full border-collapse">
//           <thead>
//             <tr className="bg-blue-100 text-gray-800">
//               <th className="py-3 px-4 text-center">S.No</th>
//               <th className="py-3 px-4 text-left">Project ID</th>
//               <th className="py-3 px-4 text-left">Client ID</th>
//               <th className="py-3 px-4 text-left">Project Name</th>
//               <th className="py-3 px-4 text-center">Billing Rate</th>
//               <th className="py-3 px-4 text-center">Start Date</th>
//               <th className="py-3 px-4 text-center">End Date</th>
//               <th className="py-3 px-4 text-center">Actions</th>
//             </tr>
//           </thead>

//           <tbody>
//             {projects.length > 0 ? (
//               projects.map((proj, index) => (
//                 <tr
//                   key={proj.id || index}
//                   className="border-t hover:bg-blue-50 transition"
//                 >
//                   <td className="py-3 px-4 text-center">{index + 1}</td>
//                   <td className="py-3 px-4">{proj.projectId}</td>
//                   <td className="py-3 px-4">{proj.clientId}</td>
//                   <td className="py-3 px-4 font-medium">{proj.projectName}</td>
//                   <td className="py-3 px-4 text-center">₹{proj.billingRate}</td>
//                   <td className="py-3 px-4 text-center">{proj.startDate}</td>
//                   <td className="py-3 px-4 text-center">{proj.endDate}</td>
//                   <td className="py-3 px-4 text-center">
//                     <div className="flex justify-center gap-3 text-lg">
//                       <button
//                         className="text-blue-600 hover:text-blue-800"
//                         onClick={() => handleEdit(proj)}
//                       >
//                         <FaEdit />
//                       </button>
//                       <button
//                         className="text-red-600 hover:text-red-800"
//                         onClick={() => confirmDelete(proj.id)}
//                       >
//                         <FaTrashAlt />
//                       </button>
//                     </div>
//                   </td>
//                 </tr>
//               ))
//             ) : (
//               <tr>
//                 <td colSpan="8" className="text-center py-6 text-gray-500">
//                   No projects found.
//                 </td>
//               </tr>
//             )}
//           </tbody>
//         </table>
//       </div>

//       {/* Add / Edit Modal */}
//       {showModal && (
//         <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
//           <div className="bg-white rounded-lg p-6 w-96 shadow-xl">
//             <h3 className="text-xl font-semibold mb-4 text-gray-800">
//               {editProjectId ? "Edit Project" : "Add Project"}
//             </h3>

//             <form onSubmit={editProjectId ? handleSave : handleAddProject}>
//               <div className="space-y-3">
//                 <input
//                   type="text"
//                   name="projectId"
//                   value={formData.projectId}
//                   onChange={handleChange}
//                   placeholder="Project ID"
//                   className="border p-2 w-full rounded"
//                 />
//                 <input
//                   type="text"
//                   name="clientId"
//                   value={formData.clientId}
//                   onChange={handleChange}
//                   placeholder="Client ID"
//                   className="border p-2 w-full rounded"
//                 />
//                 <input
//                   type="text"
//                   name="projectName"
//                   value={formData.projectName}
//                   onChange={handleChange}
//                   placeholder="Project Name"
//                   className="border p-2 w-full rounded"
//                 />
//                 <input
//                   type="number"
//                   name="billingRate"
//                   value={formData.billingRate}
//                   onChange={handleChange}
//                   placeholder="Billing Rate"
//                   className="border p-2 w-full rounded"
//                 />
//                 <input
//                   type="date"
//                   name="startDate"
//                   value={formData.startDate}
//                   onChange={handleChange}
//                   className="border p-2 w-full rounded"
//                 />
//                 <input
//                   type="date"
//                   name="endDate"
//                   value={formData.endDate}
//                   onChange={handleChange}
//                   className="border p-2 w-full rounded"
//                 />
//               </div>

//               <div className="mt-5 flex justify-end gap-3">
//                 <button
//                   type="button"
//                   className="px-4 py-2 rounded bg-gray-300 hover:bg-gray-400"
//                   onClick={() => setShowModal(false)}
//                 >
//                   Cancel
//                 </button>
//                 <button
//                   type="submit"
//                   className="px-4 py-2 rounded bg-blue-600 hover:bg-blue-700 text-white"
//                 >
//                   {editProjectId ? "Save" : "Add"}
//                 </button>
//               </div>
//             </form>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Project;



import React, { useState, useEffect } from "react";
import { FaPlus, FaEdit, FaTrashAlt, FaFolderOpen } from "react-icons/fa";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Project = () => {
  const [projects, setProjects] = useState([]);
  const [editProjectId, setEditProjectId] = useState(null);
  const [formData, setFormData] = useState({
    projectId: "",
    clientId: "",
    projectName: "",
    billingRate: "",
    startDate: "",
    endDate: "",
  });
  const [showModal, setShowModal] = useState(false);

  // 🟢 Example placeholder for fetch
  useEffect(() => {
    // Example API fetch (commented out for now)
    // fetch("http://localhost:8080/projects")
    //   .then((res) => res.json())
    //   .then((data) => setProjects(data))
    //   .catch(() => toast.info("⚠️ Backend not reachable."));
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // ✏ Edit project
  const handleEdit = (proj) => {
    setEditProjectId(proj.id);
    setFormData(proj);
    setShowModal(true);
  };

  // 💾 Save edited project
  const handleSave = (e) => {
    e.preventDefault();
    const updated = projects.map((p) =>
      p.id === editProjectId ? { ...formData } : p
    );
    setProjects(updated);
    setEditProjectId(null);
    setShowModal(false);

    toast.success("💾 Project saved successfully!", {
      position: "top-center",
      autoClose: 2500,
      theme: "colored",
    });
  };

  // ➕ Add new project
  const handleAddProject = (e) => {
    e.preventDefault();
    if (
      !formData.projectId ||
      !formData.clientId ||
      !formData.projectName ||
      !formData.billingRate ||
      !formData.startDate ||
      !formData.endDate
    ) {
      toast.warn("⚠ Please fill all required fields!", {
        position: "top-center",
        theme: "colored",
      });
      return;
    }

    const newProject = { ...formData, id: Date.now() };
    setProjects([...projects, newProject]);
    setShowModal(false);
    toast.success("✅ Project added successfully!", {
      position: "top-center",
      autoClose: 2500,
      theme: "colored",
    });
  };

  // 🗑 Professional Delete Confirmation
  const confirmDelete = (id) => {
    toast.info(
      <div className="flex flex-col items-start">
        <p className="font-semibold text-gray-800 mb-3">
          🗑️ Are you sure you want to delete this project?
        </p>
        <div className="flex justify-end w-full gap-3">
          <button
            className="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700"
            onClick={() => {
              setProjects((prev) => prev.filter((p) => p.id !== id));
              toast.dismiss();
              setTimeout(() => {
                toast.success("🗂️ Project deleted successfully!", {
                  position: "top-center",
                  autoClose: 2500,
                  theme: "colored",
                });
              }, 300);
            }}
          >
            Yes, Delete
          </button>
          <button
            className="bg-gray-300 text-gray-800 px-3 py-1 rounded hover:bg-gray-400"
            onClick={() => toast.dismiss()}
          >
            Cancel
          </button>
        </div>
      </div>,
      {
        position: "top-center",
        autoClose: false,
        closeOnClick: false,
        draggable: false,
        hideProgressBar: true,
      }
    );
  };

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      {/* Toast Notification Container */}
      <ToastContainer
        position="top-center"
        autoClose={2500}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        pauseOnHover
        draggable
        theme="colored"
      />

      <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center gap-2">
        <FaFolderOpen /> Projects
      </h2>

      {/* Add Project Button */}
      <div className="flex justify-end mb-4">
        <button
          onClick={() => {
            setShowModal(true);
            setEditProjectId(null);
            setFormData({
              projectId: "",
              clientId: "",
              projectName: "",
              billingRate: "",
              startDate: "",
              endDate: "",
            });
          }}
          className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition"
        >
          <FaPlus /> Add Project
        </button>
      </div>

      {/* Projects Table */}
      <div className="overflow-x-auto bg-white shadow-md rounded-xl">
        <table className="min-w-full border-collapse">
          <thead>
            <tr className="bg-blue-100 text-gray-800">
              <th className="py-3 px-4 text-center">S.No</th>
              <th className="py-3 px-4 text-left">Project ID</th>
              <th className="py-3 px-4 text-left">Client ID</th>
              <th className="py-3 px-4 text-left">Project Name</th>
              <th className="py-3 px-4 text-center">Billing Rate</th>
              <th className="py-3 px-4 text-center">Start Date</th>
              <th className="py-3 px-4 text-center">End Date</th>
              <th className="py-3 px-4 text-center">Actions</th>
            </tr>
          </thead>

          <tbody>
            {projects.length > 0 ? (
              projects.map((proj, index) => (
                <tr
                  key={proj.id || index}
                  className="border-t hover:bg-blue-50 transition"
                >
                  <td className="py-3 px-4 text-center">{index + 1}</td>
                  <td className="py-3 px-4">{proj.projectId}</td>
                  <td className="py-3 px-4">{proj.clientId}</td>
                  <td className="py-3 px-4 font-medium">{proj.projectName}</td>
                  <td className="py-3 px-4 text-center">₹{proj.billingRate}</td>
                  <td className="py-3 px-4 text-center">{proj.startDate}</td>
                  <td className="py-3 px-4 text-center">{proj.endDate}</td>
                  <td className="py-3 px-4 text-center">
                    <div className="flex justify-center gap-3 text-lg">
                      <button
                        className="text-blue-600 hover:text-blue-800"
                        onClick={() => handleEdit(proj)}
                      >
                        <FaEdit />
                      </button>
                      <button
                        className="text-red-600 hover:text-red-800"
                        onClick={() => confirmDelete(proj.id)}
                      >
                        <FaTrashAlt />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="8" className="text-center py-6 text-gray-500">
                  No projects found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Add / Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-96 shadow-xl">
            <h3 className="text-xl font-semibold mb-4 text-gray-800">
              {editProjectId ? "Edit Project" : "Add Project"}
            </h3>

            <form onSubmit={editProjectId ? handleSave : handleAddProject}>
              <div className="space-y-3">
                <input
                  type="text"
                  name="projectId"
                  value={formData.projectId}
                  onChange={handleChange}
                  placeholder="Project ID"
                  className="border p-2 w-full rounded"
                />
                <input
                  type="text"
                  name="clientId"
                  value={formData.clientId}
                  onChange={handleChange}
                  placeholder="Client ID"
                  className="border p-2 w-full rounded"
                />
                <input
                  type="text"
                  name="projectName"
                  value={formData.projectName}
                  onChange={handleChange}
                  placeholder="Project Name"
                  className="border p-2 w-full rounded"
                />
                <input
                  type="number"
                  name="billingRate"
                  value={formData.billingRate}
                  onChange={handleChange}
                  placeholder="Billing Rate"
                  className="border p-2 w-full rounded"
                />
                <input
                  type="date"
                  name="startDate"
                  value={formData.startDate}
                  onChange={handleChange}
                  className="border p-2 w-full rounded"
                />
                <input
                  type="date"
                  name="endDate"
                  value={formData.endDate}
                  onChange={handleChange}
                  className="border p-2 w-full rounded"
                />
              </div>

              <div className="mt-5 flex justify-end gap-3">
                <button
                  type="button"
                  className="px-4 py-2 rounded bg-gray-300 hover:bg-gray-400"
                  onClick={() => setShowModal(false)}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded bg-blue-600 hover:bg-blue-700 text-white"
                >
                  {editProjectId ? "Save" : "Add"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Project;
