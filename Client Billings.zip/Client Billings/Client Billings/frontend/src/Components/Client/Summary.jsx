import React from "react";

export default function Summary() {
  const cards = [
    { title: "Active Projects", value: "12", color: "bg-gray-500" },
    { title: "Total Invoices", value: "48", color: "bg-gray-500" },
    { title: "Paid Invoices", value: "35", color: "bg-gray-500" },
    { title: "Pending Invoices", value: "13", color: "bg-gray-500" },
  ];

  return (
    <div className="p-4 sm:p-6 lg:p-8">
      <h1 className="text-xl sm:text-2xl font-semibold text-gray-800 mb-6 text-center sm:text-left">
        Summary Overview
      </h1>

      {/* Responsive Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {cards.map((card) => (
          <div
            key={card.title}
            className={`${card.color} text-white rounded-2xl p-5 sm:p-6 shadow-lg 
              hover:scale-105 transition-transform duration-300 flex flex-col items-center sm:items-start`}
          >
            <h2 className="text-base sm:text-lg font-medium text-center sm:text-left">
              {card.title}
            </h2>
            <p className="text-2xl sm:text-3xl font-bold mt-2">{card.value}</p>
          </div>
        ))}
      </div>

      {/* Extra Responsive Section (optional) */}
      {/* <div className="mt-10 grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white shadow-md rounded-2xl p-6">
          <h3 className="text-lg sm:text-xl font-semibold mb-4 text-gray-700">
            Project Overview
          </h3>
          <div className="h-40 flex items-center justify-center text-gray-400 text-sm sm:text-base">
            📊 Chart or Analytics Section
          </div>
        </div>

        <div className="bg-white shadow-md rounded-2xl p-6">
          <h3 className="text-lg sm:text-xl font-semibold mb-4 text-gray-700">
            Invoice Insights
          </h3>
          <div className="h-40 flex items-center justify-center text-gray-400 text-sm sm:text-base">
            💰 Statistics or Graph Section
          </div>
        </div>
      </div> */}
    </div>
  );
}
