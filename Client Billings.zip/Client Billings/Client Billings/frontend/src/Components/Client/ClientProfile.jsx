import React, { useState } from "react";
import { FaUser, FaEnvelope, FaPhone, FaLock } from "react-icons/fa";
import { Eye, EyeOff } from "lucide-react";

export default function Profile() {
  const [profile, setProfile] = useState({
    name: "Gayathri Priya ",
    email: "gayathri@gmail.com",
    contact: "7995698816",
  });

  const [isEditing, setIsEditing] = useState(false);
  const [showPassword, setShowPassword] = useState({
    current: false,
    new: false,
    confirm: false,
  });

  const [passwordData, setPasswordData] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });

  const handleEdit = () => setIsEditing(true);
  const handleSave = () => setIsEditing(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setProfile({ ...profile, [name]: value });
  };

  const handlePasswordChange = (e) => {
    const { name, value } = e.target;
    setPasswordData({ ...passwordData, [name]: value });
  };

  return (
    <div className="p-6 min-h-screen bg-gray-50 flex justify-center">
      <div className="w-full max-w-2xl bg-white shadow-md rounded-lg p-6">
        {/* PERSONAL INFO */}
        <h2 className="text-xl font-semibold flex items-center gap-2 mb-4">
          <FaUser /> Personal Information
        </h2>

        <div className="space-y-4">
          <div>
            <label className="block text-gray-600 mb-1">Full Name</label>
            <input
              type="text"
              name="name"
              value={profile.name}
              onChange={handleChange}
              disabled={!isEditing}
              className={`w-full border rounded-lg px-3 py-2 ${
                isEditing
                  ? "bg-white border-gray-400"
                  : "bg-gray-100 border-gray-200"
              }`}
            />
          </div>

          <div>
            <label className="block text-gray-600 mb-1">Email</label>
            <input
              type="email"
              name="email"
              value={profile.email}
              onChange={handleChange}
              disabled={!isEditing}
              className={`w-full border rounded-lg px-3 py-2 ${
                isEditing
                  ? "bg-white border-gray-400"
                  : "bg-gray-100 border-gray-200"
              }`}
            />
          </div>

          <div>
            <label className="block text-gray-600 mb-1">Contact</label>
            <div className="relative">
              <FaPhone className="absolute left-3 top-3 text-gray-500" />
              <input
                type="text"
                name="contact"
                value={profile.contact}
                onChange={handleChange}
                disabled={!isEditing}
                className={`w-full border rounded-lg pl-10 py-2 ${
                  isEditing
                    ? "bg-white border-gray-400"
                    : "bg-gray-100 border-gray-200"
                }`}
              />
            </div>
          </div>

          <div className="flex justify-end">
            {isEditing ? (
              <button
                onClick={handleSave}
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg"
              >
                Save
              </button>
            ) : (
              <button
                onClick={handleEdit}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg"
              >
                Edit Profile
              </button>
            )}
          </div>
        </div>

        <hr className="my-6" />

        {/* CHANGE PASSWORD */}
        <h2 className="text-xl font-semibold flex items-center gap-2 mb-4">
          <FaLock /> Change Password
        </h2>

        <div className="space-y-4">
          {/* Current Password */}
          <div className="relative">
            <label className="block text-gray-600 mb-1">Current Password</label>
            <input
              type={showPassword.current ? "text" : "password"}
              name="currentPassword"
              value={passwordData.currentPassword}
              onChange={handlePasswordChange}
              placeholder="Enter current password"
              className="w-full border rounded-lg px-3 py-2 pr-10"
            />
            <button
              type="button"
              className="absolute right-3 top-8 text-gray-600"
              onClick={() =>
                setShowPassword((prev) => ({
                  ...prev,
                  current: !prev.current,
                }))
              }
            >
              {showPassword.current ? <EyeOff /> : <Eye />}
            </button>
          </div>

          {/* New Password */}
          <div className="relative">
            <label className="block text-gray-600 mb-1">New Password</label>
            <input
              type={showPassword.new ? "text" : "password"}
              name="newPassword"
              value={passwordData.newPassword}
              onChange={handlePasswordChange}
              placeholder="Enter new password"
              className="w-full border rounded-lg px-3 py-2 pr-10"
            />
            <button
              type="button"
              className="absolute right-3 top-8 text-gray-600"
              onClick={() =>
                setShowPassword((prev) => ({
                  ...prev,
                  new: !prev.new,
                }))
              }
            >
              {showPassword.new ? <EyeOff /> : <Eye />}
            </button>
          </div>

          {/* Confirm Password */}
          <div className="relative">
            <label className="block text-gray-600 mb-1">Confirm Password</label>
            <input
              type={showPassword.confirm ? "text" : "password"}
              name="confirmPassword"
              value={passwordData.confirmPassword}
              onChange={handlePasswordChange}
              placeholder="Confirm password"
              className="w-full border rounded-lg px-3 py-2 pr-10"
            />
            <button
              type="button"
              className="absolute right-3 top-8 text-gray-600"
              onClick={() =>
                setShowPassword((prev) => ({
                  ...prev,
                  confirm: !prev.confirm,
                }))
              }
            >
              {showPassword.confirm ? <EyeOff /> : <Eye />}
            </button>
          </div>

          <div className="flex justify-end">
            <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg">
              Update Password
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
