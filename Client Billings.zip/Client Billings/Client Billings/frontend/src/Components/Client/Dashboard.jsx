// import React, { useState } from "react";
// import {
//   Bell,
//   LogOut,
//   Home,
//   FileText,
//   BarChart2,
//   CreditCard,
//   User,
//   Menu, // 🍔 Hamburger icon
// } from "lucide-react";
// import { Link, Outlet, useLocation } from "react-router-dom";

// export default function Dashboard() {
//   const [sidebarOpen, setSidebarOpen] = useState(true);
//   const location = useLocation();

//   const menuItems = [
//     { name: "Summary", icon: <Home className="w-5 h-5" />, path: "/client-dashboard/summary" },
//     { name: "Invoices", icon: <FileText className="w-5 h-5" />, path: "/client-dashboard/client-invoices" },
//    { name: "Payments", icon: <CreditCard className="w-5 h-5" />, path: "/client-dashboard/payments" },
//    { name: "Projects", icon: <FileText className="w-5 h-5" />, path: "/client-dashboard/project" },
//   ];

//   const isRoot = location.pathname === "/";

//   return (
//     <div className="flex h-screen bg-gray-100">
//       {/* Sidebar */}
//       <div
//         className={`${
//           sidebarOpen ? "w-64" : "w-20"
//         } bg-gray-800 text-gray-100 flex flex-col transition-all duration-300`}
//       >
//         {/* Sidebar Header */}
//         <div className="flex items-center justify-between p-4 border-b border-gray-700">
//           {sidebarOpen && <span className="text-2xl font-bold">Client-Admin</span>}
//           {/* Hamburger Button */}
//           <button
//             onClick={() => setSidebarOpen(!sidebarOpen)}
//             className="text-gray-200 hover:text-white focus:outline-none"
//           >
//             <Menu className="w-6 h-6" />
//           </button>
//         </div>

//         {/* Sidebar Menu */}
//         <nav className="flex-1 mt-4">
//           {menuItems.map((item) => (
//             <Link
//               key={item.name}
//               to={item.path}
//               className={`flex items-center gap-3 p-4 hover:bg-gray-700 transition rounded ${
//                 location.pathname === item.path ? "bg-gray-700 font-semibold" : ""
//               }`}
//             >
//               {item.icon}
//               <span className={`${sidebarOpen ? "block" : "hidden"}`}>{item.name}</span>
//             </Link>
//           ))}
//         </nav>
//       </div>

//       {/* Main Section */}
//       <div className="flex-1 flex flex-col">
//         {/* Navbar */}
//         <header className="flex items-center justify-between bg-white shadow p-5">
//           <h1 className="text-xl font-bold text-gray-800">Client Dashboard</h1>

//           <div className="flex items-center space-x-4 relative">
//             {/* Notification */}
//             {/* <Link to="/notifications">
//               <Bell className="w-6 h-6 text-black cursor-pointer hover:bg-gray-300 p-1 rounded-full" />
//             </Link> */}

//             {/* Profile */}
//             <Link to="/ClientProfile">
//               <User className="w-6 h-6 text-black cursor-pointer hover:bg-gray-300 p-1 rounded-full" />
//             </Link>

//             {/* Logout */}
//             <Link to="/login">
//             <LogOut className="w-6 h-6 text-black cursor-pointer hover:bg-gray-300 p-1 rounded-full" />
            
//             </Link>
//           </div>
//         </header>

          

//         {/* Page Content */}
//         <main className="flex-1 p-6 overflow-auto bg-gray-50">
//           {isRoot ? (
//             <div className="flex flex-col items-center justify-center h-full text-center">
//               <h1 className="text-4xl font-bold text-gray-800 mb-4">
//                 Welcome, Admin 👋
//               </h1>
//               <p className="text-lg text-gray-600 max-w-2xl mb-8">
//                 This is your Client Billing and Resource Tracking Dashboard.
//                 Use the sidebar to navigate between Summary, Invoices, Project Progress,
//                 and Payment History.
//               </p>
//             </div>
//           ) : (
//             <Outlet />
//           )}
//         </main>
//       </div>
//     </div>
//   );
// }





import React, { useState } from "react";
import {
  LogOut,
  Home,
  FileText,
  CreditCard,
  User,
  Menu,
} from "lucide-react";
import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";

export default function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const location = useLocation();
  const navigate = useNavigate();

  const menuItems = [
    { name: "Summary", icon: <Home className="w-5 h-5" />, path: "/client-dashboard/summary" },
    { name: "Invoices", icon: <FileText className="w-5 h-5" />, path: "/client-dashboard/client-invoices" },
    { name: "Payments", icon: <CreditCard className="w-5 h-5" />, path: "/client-dashboard/payments" },
    { name: "Projects", icon: <FileText className="w-5 h-5" />, path: "/client-dashboard/project" },
  ];

  const isRoot = location.pathname === "/client-dashboard";

  const handleLogout = () => {
    localStorage.clear(); // clear session or tokens if any
    navigate("/login");
  };

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div
        className={`${
          sidebarOpen ? "w-64" : "w-20"
        } bg-gray-800 text-gray-100 flex flex-col transition-all duration-300`}
      >
        {/* Sidebar Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          {sidebarOpen && <span className="text-2xl font-bold">Client-Admin</span>}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="text-gray-200 hover:text-white focus:outline-none"
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>

        {/* Sidebar Menu */}
        <nav className="flex-1 mt-4">
          {menuItems.map((item) => (
            <Link
              key={item.name}
              to={item.path}
              className={`flex items-center gap-3 p-4 hover:bg-gray-700 transition rounded ${
                location.pathname === item.path ? "bg-gray-700 font-semibold" : ""
              }`}
            >
              {item.icon}
              <span className={`${sidebarOpen ? "block" : "hidden"}`}>{item.name}</span>
            </Link>
          ))}
        </nav>
      </div>

      {/* Main Section */}
      <div className="flex-1 flex flex-col">
        {/* Navbar */}
        <header className="flex items-center justify-between bg-white shadow p-5">
          <h1 className="text-xl font-bold text-gray-800">Client Dashboard</h1>

          <div className="flex items-center space-x-4 relative">
            {/* Profile */}
           <Link to="/client-dashboard/client-profile">
  <User className="w-6 h-6 text-black cursor-pointer hover:bg-gray-300 p-1 rounded-full" />
</Link>


            {/* Logout */}
            <button onClick={handleLogout}>
              <LogOut className="w-6 h-6 text-black cursor-pointer hover:bg-gray-300 p-1 rounded-full" />
            </button>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-6 overflow-auto bg-gray-50">
          {isRoot ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <h1 className="text-4xl font-bold text-gray-800 mb-4">
                Welcome, Admin 👋
              </h1>
              <p className="text-lg text-gray-600 max-w-2xl mb-8">
                This is your Client Billing and Resource Tracking Dashboard.
                Use the sidebar to navigate between Summary, Invoices, Project Progress,
                and Payment History.
              </p>
            </div>
          ) : (
            <Outlet />
          )}
        </main>
      </div>
    </div>
  );
}
