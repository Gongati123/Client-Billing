import React, { useState } from "react";
import { Eye, Trash2 } from "lucide-react";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import invoiceData from "./invoices.json";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export default function ClientInvoices() {
  const [invoices, setInvoices] = useState(invoiceData.invoices);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [showModal, setShowModal] = useState(false);

  const handleView = (invoice) => {
    setSelectedInvoice(invoice);
    setShowModal(true);
  };

  const handleDelete = (invoiceNo) => {
    const updated = invoices.filter((inv) => inv.invoiceNo !== invoiceNo);
    setInvoices(updated);
    toast.success(" Invoice deleted successfully!", {
      position: "top-center",
      autoClose: 2500,
    });
  };

  const handleDownload = (invoice) => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text("Invoice Details", 14, 20);

    autoTable(doc, {
      startY: 30,
      head: [["Field", "Value"]],
      body: [
        ["S.No", invoice.sno],
        ["Client Name", invoice.name],
        ["Invoice No", invoice.invoiceNo],
        ["Net Amount", `$${invoice["net amount"]}`],
        ["Status", invoice.status],
      ],
    });

    doc.save(`${invoice.invoiceNo}.pdf`);

    toast.success("📄 Invoice PDF downloaded successfully!", {
      position: "top-center",
      autoClose: 2500,
    });
  };

  return (
    <div className="p-4 md:p-6 bg-gray-50 min-h-screen">
      <ToastContainer />
      <h2 className="text-2xl font-semibold mb-6 text-gray-800">Invoices</h2>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mb-6">
        <div className="bg-white shadow rounded-xl p-4 sm:p-6 text-center">
          <h3 className="text-lg font-semibold text-gray-600">Total Invoices</h3>
          <p className="text-3xl font-bold text-blue-600 mt-2">{invoices.length}</p>
        </div>
        <div className="bg-white shadow rounded-xl p-4 sm:p-6 text-center">
          <h3 className="text-lg font-semibold text-gray-600">Paid</h3>
          <p className="text-3xl font-bold text-green-600 mt-2">
            {invoices.filter((i) => i.status === "Paid").length}
          </p>
        </div>
        <div className="bg-white shadow rounded-xl p-4 sm:p-6 text-center">
          <h3 className="text-lg font-semibold text-gray-600">Pending / Overdue</h3>
          <p className="text-3xl font-bold text-yellow-500 mt-2">
            {invoices.filter((i) => i.status !== "Paid").length}
          </p>
        </div>
      </div>

      {/* Invoice Table */}
      <div className="overflow-x-auto bg-white rounded-xl shadow-lg">
        <table className="min-w-full border-collapse text-sm">
          <thead className="bg-gray-100 text-gray-700 uppercase text-xs">
            <tr>
              <th className="py-3 px-3 sm:px-5 text-left">S.No</th>
              <th className="py-3 px-3 sm:px-5 text-left">Client Name</th>
              <th className="py-3 px-3 sm:px-5 text-left">Invoice No</th>
              <th className="py-3 px-3 sm:px-5 text-left">Net Amount</th>
              <th className="py-3 px-3 sm:px-5 text-left">Status</th>
              <th className="py-3 px-3 sm:px-5 text-left">Actions</th>
            </tr>
          </thead>
          <tbody>
            {invoices.map((invoice) => (
              <tr
                key={invoice.invoiceNo}
                className="border-b hover:bg-gray-50 transition"
              >
                <td className="py-2 px-3 sm:py-3 sm:px-5">{invoice.sno}</td>
                <td className="py-2 px-3 sm:py-3 sm:px-5">{invoice.name}</td>
                <td className="py-2 px-3 sm:py-3 sm:px-5">{invoice.invoiceNo}</td>
                <td className="py-2 px-3 sm:py-3 sm:px-5">${invoice["net amount"]}</td>
                <td
                  className={`py-2 px-3 sm:py-3 sm:px-5 font-medium ${
                    invoice.status === "Paid"
                      ? "text-green-600"
                      : invoice.status === "Pending"
                      ? "text-yellow-600"
                      : "text-red-600"
                  }`}
                >
                  {invoice.status}
                </td>
                <td className="py-2 px-3 sm:py-3 sm:px-5 flex gap-2 sm:gap-3">
                  <button
                    className="text-gray-500 hover:text-blue-500"
                    title="View Invoice"
                    onClick={() => handleView(invoice)}
                  >
                    <Eye size={18} />
                  </button>
                  <button
                    className="text-gray-500 hover:text-red-500"
                    title="Delete Invoice"
                    onClick={() => handleDelete(invoice.invoiceNo)}
                  >
                    <Trash2 size={18} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* View Modal */}
      {showModal && selectedInvoice && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
          <div className="bg-white p-4 sm:p-6 rounded-xl shadow-xl w-full max-w-md">
            <h3 className="text-lg font-semibold mb-4 text-gray-800">
              Invoice Details
            </h3>
            <div className="space-y-2 text-gray-700 text-sm">
              <p><strong>S.No:</strong> {selectedInvoice.sno}</p>
              <p><strong>Client Name:</strong> {selectedInvoice.name}</p>
              <p><strong>Invoice No:</strong> {selectedInvoice.invoiceNo}</p>
              <p><strong>Net Amount:</strong> ${selectedInvoice["net amount"]}</p>
              <p><strong>Status:</strong> {selectedInvoice.status}</p>
            </div>

            <div className="flex flex-col sm:flex-row justify-end gap-2 sm:gap-3 mt-5">
              <button
                className="bg-gray-200 px-4 py-2 rounded-lg hover:bg-gray-300"
                onClick={() => setShowModal(false)}
              >
                Close
              </button>
              <button
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                onClick={() => handleDownload(selectedInvoice)}
              >
                Download PDF
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
