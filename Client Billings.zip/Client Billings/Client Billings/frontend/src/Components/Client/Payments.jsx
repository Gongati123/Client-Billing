import React, { useEffect, useState } from "react";
import data from "./Payments.json";
import { useNavigate } from "react-router-dom";

export default function Payments() {
  const [activeTab, setActiveTab] = useState("history");
  const [payments, setPayments] = useState([]);
  const [paymentDetails, setPaymentDetails] = useState({ id: "", amount: "" });
  const navigate = useNavigate();

  useEffect(() => {
    setPayments(data.paymentHistory);
  }, []);

  // ✅ Load Razorpay Script
  const loadRazorpay = () => {
    return new Promise((resolve) => {
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = () => resolve(true);
      script.onerror = () => resolve(false);
      document.body.appendChild(script);
    });
  };

  // ✅ Handle Razorpay Payment
  const handlePayment = async (e) => {
    e.preventDefault();

    const res = await loadRazorpay();
    if (!res) {
      alert("Razorpay SDK failed to load. Check your internet connection.");
      return;
    }

    const options = {
      key: "rzp_test_1234567890abcdef", // 🔹 Replace with your Razorpay Test Key
      amount: paymentDetails.amount * 100, // Amount in paise
      currency: "INR",
      name: "Client Billing System",
      description: "Test Transaction",
      order_id: "order_" + Math.random().toString(36).substr(2, 9),
      handler: function (response) {
        alert("Payment Successful!");
        console.log("Razorpay Payment ID:", response.razorpay_payment_id);
        console.log("Razorpay Order ID:", response.razorpay_order_id);
        console.log("Razorpay Signature:", response.razorpay_signature);
      },
      prefill: {
        name: "Client User",
        email: "client@example.com",
        contact: "9999999999",
      },
      notes: {
        invoice_id: paymentDetails.id,
      },
      theme: {
        color: "#1e40af",
      },
    };

    const paymentObject = new window.Razorpay(options);
    paymentObject.open();
  };

  return (
    <div className="p-4 sm:p-6">
      <h2 className="text-2xl font-bold mb-6">Payments</h2>

      {/* Tabs */}
      <div className="flex space-x-4 mb-6 border-b border-gray-300">
        <button
          className={`pb-2 font-semibold ${
            activeTab === "history"
              ? "border-b-2 border-blue-600 text-blue-600"
              : "text-gray-600"
          }`}
          onClick={() => setActiveTab("history")}
        >
          Payment History
        </button>
        <button
          className={`pb-2 font-semibold ${
            activeTab === "make"
              ? "border-b-2 border-blue-600 text-blue-600"
              : "text-gray-600"
          }`}
          onClick={() => setActiveTab("make")}
        >
          Make Payment
        </button>
      </div>

      {/* ✅ Payment History */}
      {activeTab === "history" && (
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white shadow-md rounded-lg text-sm sm:text-base">
            <thead className="bg-gray-100 text-gray-700">
              <tr>
                <th className="py-2 px-4 text-left">ID</th>
                <th className="py-2 px-4 text-left">Amount</th>
                <th className="py-2 px-4 text-left">Payment Timestamp</th>
                <th className="py-2 px-4 text-left">Razorpay Order ID</th>
                <th className="py-2 px-4 text-left">Razorpay Payment ID</th>
                <th className="py-2 px-4 text-left">Status</th>
                <th className="py-2 px-4 text-left">Invoice ID</th>
              </tr>
            </thead>
            <tbody>
              {payments.map((p) => (
                <tr key={p.id} className="border-b hover:bg-gray-50">
                  <td className="py-2 px-4">{p.id}</td>
                  <td className="py-2 px-4">₹{p.amount}</td>
                  <td className="py-2 px-4">{p.timestamp}</td>
                  <td className="py-2 px-4">{p.razorpay_order_id}</td>
                  <td className="py-2 px-4">{p.razorpay_payment_id}</td>
                  <td
                    className={`py-2 px-4 font-semibold ${
                      p.status === "Completed"
                        ? "text-green-600"
                        : p.status === "Pending"
                        ? "text-yellow-600"
                        : "text-red-600"
                    }`}
                  >
                    {p.status}
                  </td>
                  <td className="py-2 px-4">{p.invoice_id}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* ✅ Razorpay Payment Form */}
      {activeTab === "make" && (
        <div className="max-w-md mx-auto bg-white rounded-2xl shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4 text-center">
            Make a Payment
          </h3>

          <form onSubmit={handlePayment} className="space-y-4">
            <div>
              <label className="block text-gray-700 font-medium mb-1">
                Invoice ID
              </label>
              <input
                type="text"
                required
                placeholder="Enter ID"
                value={paymentDetails.id}
                onChange={(e) =>
                  setPaymentDetails({ ...paymentDetails, id: e.target.value })
                }
                className="border border-gray-300 p-3 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-gray-700 font-medium mb-1">
                Amount (in ₹)
              </label>
              <input
                type="number"
                required
                placeholder="Enter Amount"
                value={paymentDetails.amount}
                onChange={(e) =>
                  setPaymentDetails({
                    ...paymentDetails,
                    amount: e.target.value,
                  })
                }
                className="border border-gray-300 p-3 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 transition"
            >
              Pay with Razorpay
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
