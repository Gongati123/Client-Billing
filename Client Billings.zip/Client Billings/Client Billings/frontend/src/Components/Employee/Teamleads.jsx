import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import teamLeadsData from "./teamleadsData.json";

export default function Teamleads() {
  const [teamLeads, setTeamLeads] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    setTeamLeads(teamLeadsData);
  }, []);

  return (
    <div className="p-6">
      {/* Back Button */}
      <button
        onClick={() => navigate(-1)}
        className="bg-blue-600 text-white px-4 py-2 rounded-lg shadow hover:bg-blue-700 transition mb-4"
      >
        ← Back
      </button>

      {/* Title */}
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">Team Leads</h2>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full bg-blue-400 border border-gray-200 rounded-lg shadow">
          <thead className="bg-orange-400">
            <tr>
              <th className="py-2 px-4 border-b text-left">S.No</th>
              <th className="py-2 px-4 border-b text-left">Team Lead ID</th>
              <th className="py-2 px-4 border-b text-left">Email</th>
              <th className="py-2 px-4 border-b text-left">Role</th>
            </tr>
          </thead>
          <tbody>
            {teamLeads.map((lead, index) => (
              <tr
                key={lead.id}
                className="text-left border-b hover:bg-gray-50 transition"
              >
                <td className="py-2 px-4">{index + 1}</td>
                <td className="py-2 px-4">{lead.id}</td>
                <td className="py-2 px-4">{lead.email}</td>
                <td className="py-2 px-4">{lead.role}</td>
              </tr>
            ))}
          </tbody>
        </table>
        
      </div>
    </div>
    
  );
}
