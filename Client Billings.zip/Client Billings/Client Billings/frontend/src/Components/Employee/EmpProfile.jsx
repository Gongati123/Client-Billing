


import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Profile() {
  const [user, setUser] = useState({
    name: "John Doe",
    email: "john.doe@example.com",
  });

  const [editing, setEditing] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [message, setMessage] = useState("");

  const navigate = useNavigate();

  const handleEditToggle = () => setEditing(!editing);

  const handleSaveProfile = () => {
    if (!user.name || !user.email) {
      setMessage("Name and Email cannot be empty.");
      return;
    }
    setEditing(false);
    setMessage("Profile updated successfully!");
  };

  const handlePasswordUpdate = (e) => {
    e.preventDefault();
    if (!currentPassword || !newPassword || !confirmPassword) {
      setMessage("Please fill in all password fields.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setMessage("New password and confirm password do not match.");
      return;
    }
    setMessage("Password updated successfully!");
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
  };

  return (
    <div className="max-w-md mx-auto mt-8">
      {/* ✅ Back Button */}
      <button
        onClick={() => navigate(-1)}
        className="mb-4 bg-blue-600 text-white px-4 py-2 rounded-lg shadow hover:bg-blue-700 transition"
      >
        ← Back
      </button>

      {/* Profile Card */}
      <div className="bg-blue-300 p-6 rounded-lg shadow-md text-black">
        <h2 className="text-2xl font-bold mb-4 text-center">Profile</h2>

        {/* User Info Section */}
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-semibold">User Info</h3>
            <button
              onClick={editing ? handleSaveProfile : handleEditToggle}
              className="bg-white text-black font-semibold px-3 py-1 rounded hover:bg-gray-200 transition"
            >
              {editing ? "Save" : "Edit"}
            </button>
          </div>

          <div>
            <label className="block text-black font-medium">Name</label>
            <input
              type="text"
              value={user.name}
              disabled={!editing}
              onChange={(e) => setUser({ ...user, name: e.target.value })}
              className={`w-full p-2 rounded text-gray-900 ${
                editing ? "bg-white border border-gray-300" : "bg-blue-100"
              }`}
            />
          </div>

          <div>
            <label className="block text-black font-medium">Email</label>
            <input
              type="email"
              value={user.email}
              disabled={!editing}
              onChange={(e) => setUser({ ...user, email: e.target.value })}
              className={`w-full p-2 rounded text-gray-900 ${
                editing ? "bg-white border border-gray-300" : "bg-blue-100"
              }`}
            />
          </div>
        </div>

        {/* Password Update Section */}
        <div className="mt-6 space-y-3">
          <h3 className="text-xl font-semibold">Update Password</h3>
          {message && <p className="text-yellow-800 font-medium">{message}</p>}

          <form onSubmit={handlePasswordUpdate} className="space-y-2">
            <div>
              <label className="block text-black font-medium">
                Current Password
              </label>
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="w-full p-2 rounded text-gray-900 bg-blue-100"
              />
            </div>
            <div>
              <label className="block text-black font-medium">
                New Password
              </label>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full p-2 rounded text-gray-900 bg-blue-100"
              />
            </div>
            <div>
              <label className="block text-black font-medium">
                Confirm New Password
              </label>
              <input
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full p-2 rounded text-gray-900 bg-blue-100"
              />
            </div>

            <button
              type="submit"
              className="bg-green-500 text-white font-semibold px-4 py-2 rounded hover:bg-green-600 transition"
            >
              Update Password
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
