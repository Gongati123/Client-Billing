import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import ProjectData from "./Project.json";

export default function Projects() {
  const [projects, setProjects] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    setProjects(ProjectData);
  }, []);

  return (
    <div className="p-6">
      {/* ===== Back Button at Top ===== */}
      <button
        onClick={() => navigate(-1)}
        className="bg-blue-600 text-white px-4 py-2 rounded-lg shadow hover:bg-blue-700 transition mb-4"
      >
        ← Back
      </button>

      {/* ===== Page Title ===== */}
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">Projects</h2>

      {/* ===== Projects Table ===== */}
      <div className="overflow-x-auto">
        <table className="min-w-full bg-violet-300 border border-gray-200 rounded-lg shadow">
          <thead className="bg-orange-400">
            <tr>
              <th className="py-2 px-4 border-b text-left">S.No</th>
              <th className="py-2 px-4 border-b text-left">Project ID</th>
              <th className="py-2 px-4 border-b text-left">Project Name</th>
              <th className="py-2 px-4 border-b text-left">Billing Rate</th>
              <th className="py-2 px-4 border-b text-left">Start Date</th>
              <th className="py-2 px-4 border-b text-left">End Date</th>
            </tr>
          </thead>
          <tbody>
            {projects.map((project, index) => (
              <tr
                key={project.id}
                className="text-left border-b hover:bg-gray-50 transition"
              >
                <td className="py-2 px-4">{index + 1}</td>
                <td className="py-2 px-4">{project.id}</td>
                <td className="py-2 px-4">{project.name}</td>
                <td className="py-2 px-4">{project.billingRate}</td>
                <td className="py-2 px-4">{project.startDate}</td>
                <td className="py-2 px-4">{project.endDate}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

