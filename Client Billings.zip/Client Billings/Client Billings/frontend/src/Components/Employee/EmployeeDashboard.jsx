

import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import employeeData from "./employeeData.json";

import {
  FaBell,
  FaUserCircle,
  FaTachometerAlt,
  FaClock,
  FaChartBar,
  FaTasks,
  FaUserTie,
} from "react-icons/fa";

export default function EmployeeDashboard() {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  // Notifications (static example)
  const notifications = [
    "New task assigned: API Integration",
    "Reminder: Submit work log by 6 PM",
    "Project 'UI Redesign' marked as completed",

    
  ];

  const handleLogout = () => {
    // Clear authentication data if needed
    navigate("/login");
  };

  // Employee data from JSON
  const { assignedProjects, workLogs } = employeeData;

  // Key metrics
  const totalHours = workLogs.reduce((total, log) => total + log.hours, 0);
  const completedTasks = workLogs.filter((log) => log.completed).length;
  const productivityScore =
    workLogs.length > 0
      ? Math.round((completedTasks / workLogs.length) * 100)
      : 0;

  return (
    <div className="flex min-h-screen bg-gray-100">
      {/* ================= Sidebar ================= */}
      <div className="w-64 bg-gray-900 text-gray-100 min-h-screen p-6 flex flex-col shadow-lg">
        <h2 className="text-xl font-bold mb-10 text-center tracking-wide text-white">
          Employee Dashboard
        </h2>
       


        {/* Navigation Menu */}
        <ul className="space-y-6 text-lg">
          <li className="flex items-center gap-3 p-3 hover:bg-gray-800 rounded-lg cursor-pointer transition">
            <FaClock className="text-yellow-400 text-xl" />
            <Link to="/emprojects">Projects</Link>
          </li>

          <li className="flex items-center gap-3 p-3 hover:bg-gray-800 rounded-lg cursor-pointer transition">
            <FaUserTie className="text-purple-400 text-xl" />
            <Link to="/teamleads">Team Lead</Link>
          </li>
        </ul>

        {/* Footer Section */}
        <div className="mt-auto text-center text-gray-400 text-sm pt-10">
          © 2025 Employee Portal
        </div>
      </div>

      {/* ================= Main Content ================= */}
      <div className="flex-1 flex flex-col">
        {/* ===== Navbar ===== */}
        <div className="bg-gray-800 text-white p-4 flex justify-between items-center shadow-md relative">
          {/* Dashboard Title */}
          <h2 className="font-bold text-xl tracking-wide"></h2>

          {/* Right Section */}
          <div className="flex items-center gap-6 relative">
            {/* 🔔 Notification Bell */}
            <div className="relative">
              <FaBell
                className="text-2xl cursor-pointer hover:text-yellow-400 transition"
                onClick={() => setOpen(!open)}
              />
              {notifications.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-xs text-white rounded-full w-4 h-4 flex items-center justify-center">
                  {notifications.length}
                </span>
              )}

              {/* Notification Dropdown */}
              {open && (
                <div className="absolute right-0 mt-3 w-72 bg-white text-gray-800 rounded-lg shadow-lg border border-gray-200 z-50">
                  <div className="p-3 border-b font-semibold bg-gray-100 rounded-t-lg">
                    Notifications ({notifications.length})
                  </div>
                  <ul className="max-h-60 overflow-y-auto">
                    {notifications.length > 0 ? (
                      notifications.map((note, index) => (
                        <li
                          key={index}
                          className="px-4 py-2 hover:bg-gray-50 border-b last:border-none cursor-pointer"
                        >
                          {note}
                        </li>
                      ))
                    ) : (
                      <li className="px-4 py-2 text-gray-500 text-center">
                        No new notifications
                      </li>
                    )}
                  </ul>
                </div>
              )}
            </div>

            {/* 👤 Profile Icon */}
            <Link to="/EmpProfile">
              <FaUserCircle className="text-3xl hover:text-blue-400 transition cursor-pointer" />
            </Link>

            {/* 🚪 Logout Button */}
            <button 
            onClick={handleLogout}
            className="flex items-center gap-1 bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded transition"
            >
              {/* <LogOut className="w-4 h-4" /> */}
              Logout
            </button>
          </div>
        </div>

        {/* ===== Dashboard Cards ===== */}
        <div className="flex-1 p-8">
          <h1 className="text-3xl font-bold mb-8 text-gray-800">
            Welcome back!
          </h1>

          {/* Gradient Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Projects Assigned */}
            <div className="bg-gradient-to-r from-blue-400 to-blue-600 text-white p-8 rounded-2xl shadow-md hover:shadow-xl transition-transform transform hover:scale-105">
              <h2 className="text-lg font-medium">Projects Assigned</h2>
              <p className="text-4xl font-bold mt-4">{assignedProjects.length}</p>
            </div>

            {/* Total Hours Logged */}
            <div className="bg-gradient-to-r from-green-400 to-green-600 text-white p-8 rounded-2xl shadow-md hover:shadow-xl transition-transform transform hover:scale-105">
              <h2 className="text-lg font-medium">Total Hours Logged</h2>
              <p className="text-4xl font-bold mt-4">{totalHours}</p>
            </div>

            {/* Completed Tasks */}
            <div className="bg-gradient-to-r from-indigo-400 to-indigo-600 text-white p-8 rounded-2xl shadow-md hover:shadow-xl transition-transform transform hover:scale-105">
              <h2 className="text-lg font-medium">Completed Tasks</h2>
              <p className="text-4xl font-bold mt-4">{completedTasks}</p>
            </div>

            {/* Productivity Score */}
            <div className="bg-gradient-to-r from-orange-400 to-orange-600 text-white p-8 rounded-2xl shadow-md hover:shadow-xl transition-transform transform hover:scale-105">
              <h2 className="text-lg font-medium">Productivity Score</h2>
              <p className="text-4xl font-bold mt-4">{productivityScore}%</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}