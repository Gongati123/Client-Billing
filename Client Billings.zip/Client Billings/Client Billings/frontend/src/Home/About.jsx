// import React from "react";

// const About = () => {
//   return (
//     <div className="min-h-screen bg-gray-50 text-gray-800 font-sans pt-20">
//       {/* Page Header */}
//       <section className="bg-gradient-to-r from-blue-600 to-blue-700 text-white py-16 text-center">
//         <h1 className="text-4xl font-bold mb-4">
//           About Client Billing & Resource Tracking System
//         </h1>
//         <p className="max-w-2xl mx-auto text-lg text-blue-100">
//           Simplifying client billing, project resource management, and
//           performance tracking — all in one system.
//         </p>
//       </section>

//       {/* Overview Section */}
//       <section className="container mx-auto px-6 py-16">
//         <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">
//           Overview
//         </h2>
//         <p className="text-lg text-gray-600 leading-relaxed max-w-4xl mx-auto text-center">
//           The <strong>Client Billing & Resource Tracking System</strong> is a
//           comprehensive platform that helps organizations manage clients,
//           employees, billing, and project resources efficiently. It provides
//           automation, transparency, and control over all operational workflows —
//           empowering businesses to save time and increase productivity.
//         </p>
//       </section>

//       {/* Objectives Section */}
//       <section className="bg-white py-16">
//         <div className="container mx-auto px-6">
//           <h2 className="text-3xl font-bold text-center mb-8 text-gray-800">
//             Objectives
//           </h2>
//           <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
//             {[
//               "Automate billing to reduce manual errors.",
//               "Track and allocate resources effectively.",
//               "Provide role-based dashboards for better control.",
//               "Improve transparency and client communication.",
//               "Generate reports for better decision-making.",
//             ].map((obj, i) => (
//               <div
//                 key={i}
//                 className="bg-blue-50 border border-blue-100 rounded-xl p-6 shadow-sm hover:shadow-md transition"
//               >
//                 <p className="text-gray-700">{obj}</p>
//               </div>
//             ))}
//           </div>
//         </div>
//       </section>

//       {/* User Roles Section */}
//       <section className="py-16 bg-gray-50">
//         <div className="container mx-auto px-6">
//           <h2 className="text-3xl font-bold text-center mb-10 text-gray-800">
//             User Roles
//           </h2>
//           <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
//             {[
//               {
//                 role: "Admin",
//                 desc: "Manages clients, employees, projects, and billing details. Oversees analytics and reporting.",
//               },
//               {
//                 role: "Client",
//                 desc: "Views invoices, project status, and payment history. Tracks service usage and communicates with admin.",
//               },
//               {
//                 role: "Employee",
//                 desc: "Updates tasks, monitors project progress, and reports daily work or resources used.",
//               },
//             ].map((user, i) => (
//               <div
//                 key={i}
//                 className="bg-white rounded-xl shadow-md p-8 border-t-4 border-blue-600 hover:shadow-lg transition"
//               >
//                 <h3 className="text-xl font-semibold text-blue-600 mb-3">
//                   {user.role}
//                 </h3>
//                 <p className="text-gray-700">{user.desc}</p>
//               </div>
//             ))}
//           </div>
//         </div>
//       </section>

//       {/* Features Section */}
//       <section className="bg-white py-16">
//         <div className="container mx-auto px-6 text-center">
//           <h2 className="text-3xl font-bold mb-8 text-gray-800">
//             Key Features
//           </h2>
//           <div className="grid md:grid-cols-3 gap-10">
//             {[
//               {
//                 title: "Automated Billing",
//                 text: "Easily generate and manage client invoices with accuracy and transparency.",
//               },
//               {
//                 title: "Resource Tracking",
//                 text: "Monitor workloads, resource allocation, and team performance in real-time.",
//               },
//               {
//                 title: "Reports & Analytics",
//                 text: "Generate detailed reports to support management and client decisions.",
//               },
//             ].map((f, i) => (
//               <div
//                 key={i}
//                 className="bg-blue-50 rounded-xl shadow-sm hover:shadow-lg p-8 border border-blue-100 transition"
//               >
//                 <h3 className="text-xl font-semibold text-blue-600 mb-3">
//                   {f.title}
//                 </h3>
//                 <p className="text-gray-700">{f.text}</p>
//               </div>
//             ))}
//           </div>
//         </div>
//       </section>

//       {/* Technology Stack Section */}
//       <section className="bg-gray-50 py-16">
//         <div className="container mx-auto px-6 text-center">
//           <h2 className="text-3xl font-bold text-gray-800 mb-8">
//             Technology Stack
//           </h2>
//           <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
//             {[
//               ["Frontend", "React.js, Tailwind CSS"],
//               ["Backend", "Node.js or Spring Boot"],
//               ["Database", "MySQL"],
//               ["Authentication", "JWT (JSON Web Token)"],
//               ["Version Control", "Git & GitHub"],
//               ["Deployment", "Vercel / Render / AWS"],
//             ].map(([tech, tools], i) => (
//               <div
//                 key={i}
//                 className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg border-t-4 border-blue-600 transition"
//               >
//                 <h4 className="text-xl font-semibold text-blue-600 mb-2">
//                   {tech}
//                 </h4>
//                 <p className="text-gray-700">{tools}</p>
//               </div>
//             ))}
//           </div>
//         </div>
//       </section>

//       {/* Conclusion Section */}
//       <section className="py-16 bg-white text-center">
//         <div className="container mx-auto px-6 max-w-3xl">
//           <h2 className="text-3xl font-bold text-gray-800 mb-6">Conclusion</h2>
//           <p className="text-lg text-gray-600 leading-relaxed">
//             The <strong>Client Billing & Resource Tracking System</strong> offers
//             a complete digital solution to streamline billing, manage project
//             resources, and monitor employee performance. With role-based access,
//             analytics, and automation, it ensures greater transparency,
//             accuracy, and operational efficiency across your organization.
//           </p>
//         </div>
//       </section>

//       {/* Footer */}
//       <footer className="bg-blue-600 text-white text-center py-6 mt-10">
//         <p>
//           © {new Date().getFullYear()} Client Billing & Resource Tracking
//           System. All Rights Reserved.
//         </p>
//       </footer>
//     </div>
//   );
// };

// export default About;


import React from "react";
import { FaUsers, FaLaptopCode, FaChartLine, FaRegSmile } from "react-icons/fa";

const About = () => {
  return (
    <div className="bg-gradient-to-r from-blue-50 to-blue-100 min-h-screen text-gray-800">
      {/* 🌟 Hero Section */}
      <section className="bg-gradient-to-r from-blue-500 to-gray-500 text-white py-20 text-center px-6">
        <h1 className="text-5xl font-bold mb-4">About Our System</h1>
        <p className="text-lg max-w-3xl mx-auto">
          Empowering businesses to manage clients, employees, and billing efficiently
          with a streamlined and intelligent resource tracking solution.
        </p>
      </section>

      {/* 🧠 Mission Section */}
      {/* <section className="py-16 container mx-auto px-6 grid md:grid-cols-2 gap-10 items-center">
        <div >
          <img
            // src="https://img.freepik.com/free-vector/business-team-analyzing-growth-charts_1262-20656.jpg"
            src="Images/Invocie1.jpg"
            alt="Our Mission"
            className="rounded-3xl w-full h-1000 shadow-lg"
          />
        </div>
        <div>
          <h2 className="text-3xl font-semibold mb-4 text-blue-700">
            Our Mission
          </h2>
          <p className="text-gray-700 mb-4 leading-relaxed">
            Our mission is to simplify how companies handle "client billing, project
            management, and employee performance tracking". We aim to deliver
            a platform that’s intuitive, secure, and scalable for organizations of all sizes.
          </p>
          <p className="text-gray-700 leading-relaxed">
            By reducing manual effort and automating repetitive billing and resource
            allocation tasks, we help teams focus more on growth and client satisfaction.
          </p>
        </div>
      </section> */}

      <section className="py-20 container mx-auto px-8 grid md:grid-cols-2 gap-8 items-center">
 
  {/* <div className="flex justify-center md:justify-end"> */}
  <div >
          <img
            src="https://img.freepik.com/free-vector/business-team-analyzing-growth-charts_1262-20656.jpg"
            // src="Images/Invocie1.jpg"
            alt="Our Mission"
            className="rounded-3xl w-full h-1000 shadow-lg"
          />
   </div>

  {/* 📄 Text Section */}
  <div className="md:pl-8">
    <h2 className="text-4xl font-bold mb-5 text-blue-700">Our Mission</h2>

    <p className="text-gray-700 mb-4 leading-relaxed text-justify">
      At <span className="font-semibold text-blue-600">Client Billing and Resource Tracking System</span>,
      our mission is to transform how companies manage client projects, billing, and internal resources.
      We strive to bring transparency, accuracy, and efficiency to business operations by combining
      modern technology with smart automation.
    </p>

    {/* <p className="text-gray-700 mb-4 leading-relaxed text-justify">
      Our platform enables organizations to simplify their workflows — from generating invoices and
      tracking project progress to monitoring team performance and client satisfaction. We aim to
      eliminate manual bottlenecks and provide data-driven insights that empower better decision-making.
    </p> */}

    <p className="text-gray-700 mb-4 leading-relaxed text-justify">
      By automating repetitive billing and time-tracking tasks, our system helps businesses save time,
      reduce errors, and improve client relationships. We focus on providing a secure, scalable,
      and intuitive platform that grows with your organization.
    </p>

    <p className="text-gray-700 mb-4 leading-relaxed text-justify">
      Whether you’re a small startup or a large enterprise, our mission is to make managing clients
      and projects effortless — so your team can focus on what truly matters: innovation, growth,
      and customer success.
    </p>

    <div className="mt-6">
      <ul className="list-disc list-inside text-gray-700 leading-relaxed space-y-2">
        <li><strong>Transparency:</strong> Real-time billing and tracking for better accountability.</li>
        <li><strong>Automation:</strong> Reduce manual tasks and human errors.</li>
        <li><strong>Scalability:</strong> Designed to support teams of any size or complexity.</li>
        <li><strong>Security:</strong> Protecting your data with advanced encryption and access control.</li>
      </ul>
    </div>
    </div>
  </section>


      {/* 💡 Vision Section */}
      <section className="py-16 bg-gradient-to-r from-blue-50 to-blue-100 container mx-auto px-6 grid md:grid-cols-2 gap-10 items-center">
        <div className="order-2 md:order-1">
          <h2 className="text-3xl font-semibold mb-4 text-blue-700">
            Our Vision
          </h2>
          <p className="text-gray-700 mb-4 leading-relaxed">
            We envision a world where "business operations are fully optimized" through
            intelligent automation and data-driven insights. Our system bridges the gap
            between management, employees, and clients with transparency and accuracy.
          </p>
          <p className="text-gray-700 leading-relaxed">
            Our goal is to become the most trusted partner for organizations looking
            to modernize their financial and operational systems.
          </p>
        </div>
        <div className="order-1 md:order-2">
          <img
            src="Images/Vision.jpg"
            alt="Our Vision"
            className="rounded-2xl shadow-lg"
          />
        </div>
      </section>

      {/* 🚀 What We Offer */}
      <section className="py-16 bg-blue-50">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl font-semibold mb-12 text-blue-800">
            What We Offer
          </h2>
          <div className="grid md:grid-cols-4 gap-8">
            <div className="bg-white shadow-lg rounded-xl p-8 hover:shadow-xl transition">
              <FaUsers className="text-blue-600 text-4xl mb-4 mx-auto" />
              <h4 className="text-xl font-semibold mb-3">Client Management</h4>
              <p className="text-gray-600">
                Easily add, update, and manage client data and billing details
                with an organized and user-friendly interface.
              </p>
            </div>
            <div className="bg-white shadow-lg rounded-xl p-8 hover:shadow-xl transition">
              <FaLaptopCode className="text-blue-600 text-4xl mb-4 mx-auto" />
              <h4 className="text-xl font-semibold mb-3">Employee Tracking</h4>
              <p className="text-gray-600">
                Monitor performance, allocate work efficiently, and ensure
                balanced workloads across your organization.
              </p>
            </div>
            <div className="bg-white shadow-lg rounded-xl p-8 hover:shadow-xl transition">
              <FaChartLine className="text-blue-600 text-4xl mb-4 mx-auto" />
              <h4 className="text-xl font-semibold mb-3">Smart Reporting</h4>
              <p className="text-gray-600">
                Generate insightful analytics and financial summaries that
                empower smarter decision-making.
              </p>
            </div>
            <div className="bg-white shadow-lg rounded-xl p-8 hover:shadow-xl transition">
              <FaRegSmile className="text-blue-600 text-4xl mb-4 mx-auto" />
              <h4 className="text-xl font-semibold mb-3">User-Friendly UI</h4>
              <p className="text-gray-600">
                Enjoy a clean, modern interface designed for smooth navigation
                and a better overall experience.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 💬 Closing Section */}
      <section className="bg-gradient-to-r from-blue-500 to-gray-500 text-white text-center py-16 px-6">
        <h2 className="text-3xl font-bold mb-4">Join Us in Redefining Efficiency</h2>
        <p className="max-w-3xl mx-auto text-lg mb-8">
          Whether you’re a startup or an enterprise, our Client Billing & Resource
          Tracking System adapts to your needs and helps you scale effortlessly.
        </p>
        <a
          href="/contact"
          className="bg-white text-blue-700 px-6 py-3 rounded-lg font-semibold shadow-md hover:bg-gray-100 transition"
        >
          Get in Touch
        </a>
      </section>
    </div>
  );
};

export default About;
