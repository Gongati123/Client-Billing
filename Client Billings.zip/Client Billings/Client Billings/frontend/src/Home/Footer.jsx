import React from "react";
import { Link } from "react-router-dom";
import { FaFacebookF, FaTwitter, FaLinkedinIn, FaInstagram } from "react-icons/fa";

export default function Footer() {
  return (
    <footer className="bg-black text-white py-10 px-6">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
        
        {/* Logo + Description */}
        <div>
          <h2 className="text-2xl font-bold mb-3">Smart Billing</h2>
          <p className="text-sm text-gray-200">
            Manage clients, employees, and projects efficiently — 
            your all-in-one business billing solution.
          </p>
        </div>

        {/* Quick Links */}
        <div>
          <h3 className="text-lg font-semibold mb-3">Quick Links</h3>
          <ul className="space-y-2 text-gray-200">
            <li>
              <Link to="/" className="hover:text-gray-100 transition">Home</Link>
            </li>
            <li>
              <Link to="/about" className="hover:text-gray-100 transition">About</Link>
            </li>
            <li>
              <Link to="/contact" className="hover:text-gray-100 transition">Contact</Link>
            </li>
            <li>
              <Link to="/login" className="hover:text-gray-100 transition">Login</Link>
            </li>
          </ul>
        </div>

        {/* Social Links */}
        <div>
          <h3 className="text-lg font-semibold mb-3">Follow Us</h3>
          <div className="flex justify-center md:justify-start gap-4">
            <a href="#" className="p-2 bg-white/20 rounded-full hover:bg-white/30 transition">
              <FaFacebookF />
            </a>
            <a href="#" className="p-2 bg-white/20 rounded-full hover:bg-white/30 transition">
              <FaTwitter />
            </a>
            <a href="#" className="p-2 bg-white/20 rounded-full hover:bg-white/30 transition">
              <FaLinkedinIn />
            </a>
            <a href="#" className="p-2 bg-white/20 rounded-full hover:bg-white/30 transition">
              <FaInstagram />
            </a>
          </div>
        </div>
      </div>

      {/* Bottom Line */}
      <div className="border-t border-gray-400 mt-8 pt-4 text-center text-sm text-gray-300">
        © {new Date().getFullYear()} Smart Billing. All rights reserved.
      </div>
    </footer>
  );
}
