import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <div className="font-sans text-white">
      {/* 🌐 Navbar */}
      <header className="bg-gray-900 shadow-md fixed w-full top-0 z-50">
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-blue-600">
            Smart Billing 
          </h1>
          <nav className="space-x-6">
            <Link to="/" className="hover:text-blue-600 font-medium">
              Home
            </Link>
            <Link to="/about" className="hover:text-blue-600 font-medium">
              About
            </Link>
            <Link to="/contact" className="hover:text-blue-600 font-medium">
              Contact
            </Link>
            <Link
              to="/login"
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition"
            >
              Login
            </Link>
            <Link
              to="/signup"
              className="border border-blue-600 text-blue-600 px-4 py-2 rounded-lg hover:bg-blue-50 transition"
            >
              Signup
            </Link>
          </nav>
        </div>
      </header>
      </div>
   );
};
export default Navbar;


