// import React, { useState } from "react";
// import { Link } from "react-router-dom";
// import { motion } from "framer-motion";

// import {
//   CheckCircle,
//   Users,
//   FileText,
//   BarChart3,
//   Briefcase,
//   Settings,
// } from "lucide-react";

// const Home = () => {
//   // 🌟 Contact Form State
//   const [formData, setFormData] = useState({
//     name: "",
//     email: "",
//     message: "",
//   });
//   const [error, setError] = useState("");
//   const [success, setSuccess] = useState("");

//   // 🖊 Handle Form Input
//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//     setError("");
//     setSuccess("");
//   };

//   // 🚀 Handle Submit
//   const handleSubmit = (e) => {
//     e.preventDefault();

//     const { name, email, message } = formData;

//     if (!name || !email || !message) {
//       setError("⚠️ Please fill all the fields before submitting.");
//       return;
//     }

//     // ✅ Success message
//     setSuccess("✅ Message sent successfully!");
//     console.log("Form Data Submitted:", formData);

//     // Optional: Clear form after success
//     setFormData({ name: "", email: "", message: "" });
//   };

//   return (
//     <div className="font-sans bg-Pale Robin Egg Blue text-white">
      
//       <div className="font-sans text-black bg-gray-900 min-h-screen flex items-center justify-center text-center px-6">
//   {/* 🏠 Hero Section */}
//   <section
//   className="min-h-screen w-full flex items-center justify-center bg-cover bg-center bg-no-repeat text-white px-8"
//   style={{
//     backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('/Images/Bg1.jpeg')`,
//   }}
// >

//   <div className="max-w-4xl text-center">
//     <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold mb-6 leading-snug">
//       Empower Your Business with Smart Billing & Resource Management
//     </h1>

//     <p className="text-base sm:text-lg md:text-xl mb-8 leading-relaxed">
//       The ultimate platform for managing client billing, tracking employee
//       resources, and monitoring project efficiency — all from one intuitive dashboard.
//     </p>

//     <div className="mt-10 text-gray-200 text-sm sm:text-base font-medium">
//       Trusted by startups, growing teams, and enterprises across industries.
//     </div>
//     <br></br>

//     <Link to="/login" className="mt-8 bg-[#c77dff] hover:bg-[#b357ff] text-white px-8 py-3 rounded-full text-lg font-semibold transition-all shadow-lg">
//       Get Started
//     </Link>
//   </div>
// </section>

//     </div>


//       {/* 💡 Features Section */}
//       <section className="py-20 bg-gradient-to-r from-blue-50 to-blue-100" id="features">
//         <div className="container mx-auto px-6 text-center">
//           <h2 className="text-4xl font-bold text-gray-800 mb-12">
//             Why Choose Our Platform
//           </h2>

//           <div className="grid md:grid-cols-3 gap-10">
//             <div className="bg-white shadow-lg rounded-xl p-8 hover:-translate-y-2 transition-all border-t-4 border-blue-600">
//               <FileText className="mx-auto text-blue-600 w-12 h-12 mb-4" />
//               <h4 className="text-xl font-semibold text-gray-800 mb-3">
//                 Automated Billing
//               </h4>
//               <p className="text-gray-600">
//                 Say goodbye to manual invoice generation. Create, track, and send
//                 invoices instantly with automatic reminders and payment tracking.
//               </p>
//             </div>

//             <div className="bg-white shadow-lg rounded-xl p-8 hover:-translate-y-2 transition-all border-t-4 border-indigo-600">
//               <BarChart3 className="mx-auto text-blue-600 w-12 h-12 mb-4" />
//               <h4 className="text-xl font-semibold text-gray-800 mb-3">
//                 Real-Time Analytics
//               </h4>
//               <p className="text-gray-600">
//                 Access detailed performance metrics and insights that help you
//                 make data-driven decisions and optimize your workflow efficiency.
//               </p>
//             </div>

//             <div className="bg-white shadow-lg rounded-xl p-8 hover:-translate-y-2 transition-all border-t-4 border-blue-600">
//               <Users className="mx-auto text-blue-600 w-12 h-12 mb-4" />
//               <h4 className="text-xl font-semibold text-gray-800 mb-3">
//                 Team Collaboration
//               </h4>
//               <p className="text-gray-600">
//                 Empower your teams with real-time updates, easy communication,
//                 and shared access to important project and billing data.
//               </p>
//             </div>

//             <div className="bg-white shadow-lg rounded-xl p-8 hover:-translate-y-2 transition-all border-t-4 border-indigo-600">
//               <Briefcase className="mx-auto text-blue-600 w-12 h-12 mb-4" />
//               <h4 className="text-xl font-semibold text-gray-800 mb-3">
//                 Project Management
//               </h4>
//               <p className="text-gray-600">
//                 Create, assign, and monitor projects with timeline tracking,
//                 status updates, and visual progress indicators.
//               </p>
//             </div>

//             <div className="bg-white shadow-lg rounded-xl p-8 hover:-translate-y-2 transition-all border-t-4 border-blue-600">
//               <Settings className="mx-auto text-blue-600 w-12 h-12 mb-4" />
//               <h4 className="text-xl font-semibold text-gray-800 mb-3">
//                 Customizable Workflows
//               </h4>
//               <p className="text-gray-600">
//                 Tailor workflows, access levels, and dashboards to match your
//                 company’s specific processes and team structure.
//               </p>
//             </div>

//             <div className="bg-white shadow-lg rounded-xl p-8 hover:-translate-y-2 transition-all border-t-4 border-indigo-600">
//               <CheckCircle className="mx-auto text-blue-600 w-12 h-12 mb-4" />
//               <h4 className="text-xl font-semibold text-gray-800 mb-3">
//                 Secure Access Control
//               </h4>
//               <p className="text-gray-600">
//                 Multi-role authentication ensures Admins, Clients, and Employees
//                 access only the information relevant to them.
//               </p>
//             </div>
//           </div>
//         </div>
//       </section>

//       {/* 🧍 About Section */}
//       <section className="py-20 bg-gradient-to-r from-blue-50 to-blue-100" id="about">
//         <div className="container mx-auto px-6 flex flex-col md:flex-row items-center gap-10">
//           <img
//             src="https://img.freepik.com/free-vector/data-dashboard-concept-illustration_114360-6963.jpg?t=st=1734223750~exp=1734227350~hmac=3c0d9cb621b1a06c5d05ad0f7ff8330a88d4a7a66f17eb1756021f2b5fa63a0b&w=826"
//             alt="About Us"
//             className="rounded-xl shadow-md w-full md:w-1/2"
//           />
//           <div className="md:w-1/2 text-center md:text-left">
//             <h2 className="text-4xl font-bold text-gray-800 mb-6">About Us</h2>
//             <p className="text-lg text-gray-600 leading-relaxed mb-6">
//               The <strong>Client Billing & Resource Tracking System</strong> was
//               designed to help organizations transform manual billing,
//               communication, and management into a single, powerful digital
//               experience.
//             </p>
//             <p className="text-lg text-gray-600 leading-relaxed mb-6">
//               Our mission is to provide businesses with tools that simplify
//               financial operations, improve team collaboration, and bring
//               transparency across departments.
//             </p>

//             <ul className="space-y-3 text-gray-700">
//               <li className="flex items-center gap-3">
//                 <CheckCircle className="text-blue-600" /> Trusted by 500+
//                 businesses globally
//               </li>
//               <li className="flex items-center gap-3">
//                 <CheckCircle className="text-blue-600" /> Designed for scalability
//                 and security
//               </li>
//               <li className="flex items-center gap-3">
//                 <CheckCircle className="text-blue-600" /> Backed by 24/7 customer
//                 support
//               </li>
//             </ul>
//           </div>
//         </div>
//       </section>

//       {/* 📞 Contact Section */}
//       <section className="py-20 bg-gradient-to-r from-blue-50 to-blue-100" id="contact">
//         <div className="container mx-auto px-6 md:px-12 lg:px-20">
//           <div className="text-center mb-12">
//             <h3 className="text-4xl font-bold text-gray-800 mb-4">
//               Get in Touch
//             </h3>
//             <p className="text-gray-600 text-lg max-w-2xl mx-auto">
//               We'd love to hear from you! Whether you have questions about our
//               product, need technical support, or want to explore partnership
//               opportunities — our team is ready to help.
//             </p>
//           </div>

//           <div className="grid md:grid-cols-2 gap-10 items-center">
//             {/* Left: Contact Info + Image */}
//             <div className="space-y-6">
//               <img
//                src="Images/Contact.jpg" 
//                alt="Contact illustration"
//                 className="rounded-xl w-full h-full shadow-md"
//               />

//               <div className="bg-white p-6 rounded-xl shadow-md space-y-4">
//                 <div className="flex items-center gap-4">
//                   <span className="text-blue-600 text-2xl">📧</span>
//                   <p className="text-gray-700">mounikamtala@gmail.com</p>
//                 </div>
//                 <div className="flex items-center gap-4">
//                   <span className="text-blue-600 text-2xl">📞</span>
//                   <p className="text-gray-700">+91 6303332010</p>
//                 </div>
//                 <div className="flex items-center gap-4">
//                   <span className="text-blue-600 text-2xl">📍</span>
//                   <p className="text-gray-700">Hyderabad, India</p>
//                 </div>
//               </div>
//             </div>

//             {/* Right: Contact Form */}
//             <form onSubmit={handleSubmit} className="bg-white p-8 rounded-xl shadow-lg space-y-6">
//               <div>
//                 <label className="block text-left text-gray-700 font-semibold mb-2">
//                   Your Name
//                 </label>
//                 <input
//                   type="text"
//                   name="name"
//                   placeholder="Enter your name"
//                   value={formData.name}
//                   onChange={handleChange}
//                   className="w-full border text-black border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 outline-none"
//                 />
//               </div>

//               <div>
//                 <label className="block text-left  text-gray-700 font-semibold mb-2">
//                   Your Email
//                 </label>
//                 <input
//                   type="email"
//                   name="email"
//                   placeholder="Enter your email"
//                   value={formData.email}
//                   onChange={handleChange}
//                   className="w-full border text-black border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 outline-none"
//                 />
//               </div>

//               <div>
//                 <label className="block text-left text-gray-700 font-semibold mb-2">
//                   Message
//                 </label>
//                 <textarea
//                   name="message"
//                   placeholder="Write your message"
//                   rows="4"
//                   value={formData.message}
//                   onChange={handleChange}
//                   className="w-full border text-black border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 outline-none"
//                 ></textarea>
//               </div>

//               {error && <p className="text-red-500 text-center">{error}</p>}
//               {success && <p className="text-green-600 text-center">{success}</p>}

//               <button
//                 type="submit"
//                 className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-all shadow-md"
//               >
//                 Send Message
//               </button>
//             </form>
//           </div>
//         </div>
//       </section>

   
     
//     </div>
//   );
// };

// export default Home;



import React, { useState } from "react";
import { Link } from "react-router-dom";
import { CheckCircle, Users, FileText, BarChart3, Briefcase, Settings } from "lucide-react";

const Home = () => {
  // Contact Form State
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Handle Form Input
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setError("");
    setSuccess("");
  };

  // Handle Submit
  const handleSubmit = (e) => {
    e.preventDefault();
    const { name, email, message } = formData;
    if (!name || !email || !message) {
      setError("⚠️ Please fill all the fields before submitting.");
      return;
    }
    setSuccess("✅ Message sent successfully!");
    console.log("Form Data Submitted:", formData);
    setFormData({ name: "", email: "", message: "" });
  };

  return (
    <div className="font-sans text-gray-800">
      {/* Hero Section */}
      <section
        className="min-h-screen w-full flex items-center justify-center bg-cover bg-center bg-no-repeat text-white px-4 sm:px-8"
        style={{
          backgroundImage: `linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)), url('/Images/Bg1.jpeg')`,
        }}
      >
        <div className="max-w-4xl text-center">
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6 leading-snug">
            Empower Your Business with Smart Billing & Resource Management
          </h1>
          <p className="text-base sm:text-lg md:text-xl mb-8 leading-relaxed">
            The ultimate platform for managing client billing, tracking employee
            resources, and monitoring project efficiency — all from one intuitive dashboard.
          </p>
          <div className="mt-10 text-gray-200 text-sm sm:text-base font-medium">
            Trusted by startups, growing teams, and enterprises across industries.
          </div>
          <br />
          <Link
            to="/login"
            className="mt-8 inline-block bg-[#c77dff] hover:bg-[#b357ff] text-white px-6 sm:px-8 py-2 sm:py-3 rounded-full text-lg sm:text-xl font-semibold transition-all shadow-lg"
          >
            Get Started
          </Link>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gradient-to-r from-blue-50 to-blue-100" id="features">
        <div className="container mx-auto px-4 sm:px-6 text-center">
          <h2 className="text-3xl sm:text-4xl md:text-4xl font-bold text-gray-800 mb-12">
            Why Choose Our Platform
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 md:gap-10">
            {/* Feature Card 1 */}
            <div className="bg-white shadow-lg rounded-xl p-6 sm:p-8 hover:-translate-y-2 transition-all border-t-4 border-blue-600">
              <FileText className="mx-auto text-blue-600 w-10 h-10 sm:w-12 sm:h-12 mb-4" />
              <h4 className="text-lg sm:text-xl font-semibold text-gray-800 mb-3">
                Automated Billing
              </h4>
              <p className="text-sm sm:text-base text-gray-600">
                Say goodbye to manual invoice generation. Create, track, and send
                invoices instantly with automatic reminders and payment tracking.
              </p>
            </div>

            {/* Feature Card 2 */}
            <div className="bg-white shadow-lg rounded-xl p-6 sm:p-8 hover:-translate-y-2 transition-all border-t-4 border-indigo-600">
              <BarChart3 className="mx-auto text-blue-600 w-10 h-10 sm:w-12 sm:h-12 mb-4" />
              <h4 className="text-lg sm:text-xl font-semibold text-gray-800 mb-3">
                Real-Time Analytics
              </h4>
              <p className="text-sm sm:text-base text-gray-600">
                Access detailed performance metrics and insights that help you
                make data-driven decisions and optimize your workflow efficiency.
              </p>
            </div>

            {/* Feature Card 3 */}
            <div className="bg-white shadow-lg rounded-xl p-6 sm:p-8 hover:-translate-y-2 transition-all border-t-4 border-blue-600">
              <Users className="mx-auto text-blue-600 w-10 h-10 sm:w-12 sm:h-12 mb-4" />
              <h4 className="text-lg sm:text-xl font-semibold text-gray-800 mb-3">
                Team Collaboration
              </h4>
              <p className="text-sm sm:text-base text-gray-600">
                Empower your teams with real-time updates, easy communication,
                and shared access to important project and billing data.
              </p>
            </div>

            {/* Feature Card 4 */}
            <div className="bg-white shadow-lg rounded-xl p-6 sm:p-8 hover:-translate-y-2 transition-all border-t-4 border-indigo-600">
              <Briefcase className="mx-auto text-blue-600 w-10 h-10 sm:w-12 sm:h-12 mb-4" />
              <h4 className="text-lg sm:text-xl font-semibold text-gray-800 mb-3">
                Project Management
              </h4>
              <p className="text-sm sm:text-base text-gray-600">
                Create, assign, and monitor projects with timeline tracking,
                status updates, and visual progress indicators.
              </p>
            </div>

            {/* Feature Card 5 */}
            <div className="bg-white shadow-lg rounded-xl p-6 sm:p-8 hover:-translate-y-2 transition-all border-t-4 border-blue-600">
              <Settings className="mx-auto text-blue-600 w-10 h-10 sm:w-12 sm:h-12 mb-4" />
              <h4 className="text-lg sm:text-xl font-semibold text-gray-800 mb-3">
                Customizable Workflows
              </h4>
              <p className="text-sm sm:text-base text-gray-600">
                Tailor workflows, access levels, and dashboards to match your
                company’s specific processes and team structure.
              </p>
            </div>

            {/* Feature Card 6 */}
            <div className="bg-white shadow-lg rounded-xl p-6 sm:p-8 hover:-translate-y-2 transition-all border-t-4 border-indigo-600">
              <CheckCircle className="mx-auto text-blue-600 w-10 h-10 sm:w-12 sm:h-12 mb-4" />
              <h4 className="text-lg sm:text-xl font-semibold text-gray-800 mb-3">
                Secure Access Control
              </h4>
              <p className="text-sm sm:text-base text-gray-600">
                Multi-role authentication ensures Admins, Clients, and Employees
                access only the information relevant to them.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-gradient-to-r from-blue-50 to-blue-100" id="about">
        <div className="container mx-auto px-4 sm:px-6 flex flex-col md:flex-row items-center gap-10">
          <img
            src="https://img.freepik.com/free-vector/data-dashboard-concept-illustration_114360-6963.jpg"
            alt="About Us"
            className="rounded-xl shadow-md w-full md:w-1/2 h-auto"
          />
          <div className="md:w-1/2 text-center md:text-left">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-800 mb-6">About Us</h2>
            <p className="text-base sm:text-lg text-gray-600 leading-relaxed mb-4">
              The <strong>Client Billing & Resource Tracking System</strong> was
              designed to help organizations transform manual billing,
              communication, and management into a single, powerful digital
              experience.
            </p>
            <p className="text-base sm:text-lg text-gray-600 leading-relaxed mb-4">
              Our mission is to provide businesses with tools that simplify
              financial operations, improve team collaboration, and bring
              transparency across departments.
            </p>
            <ul className="space-y-3 text-gray-700">
              <li className="flex items-center gap-3">
                <CheckCircle className="text-blue-600" /> Trusted by 500+ businesses globally
              </li>
              <li className="flex items-center gap-3">
                <CheckCircle className="text-blue-600" /> Designed for scalability and security
              </li>
              <li className="flex items-center gap-3">
                <CheckCircle className="text-blue-600" /> Backed by 24/7 customer support
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-gradient-to-r from-blue-50 to-blue-100" id="contact">
        <div className="container mx-auto px-4 sm:px-6 lg:px-20">
          <div className="text-center mb-12">
            <h3 className="text-3xl sm:text-4xl font-bold text-gray-800 mb-4">
              Get in Touch
            </h3>
            <p className="text-base sm:text-lg text-gray-600 max-w-2xl mx-auto">
              We'd love to hear from you! Whether you have questions about our
              product, need technical support, or want to explore partnership
              opportunities — our team is ready to help.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
            {/* Left: Contact Info + Image */}
            <div className="space-y-6">
              <img
                src="Images/Contact.jpg"
                alt="Contact illustration"
                className="rounded-xl w-full h-auto shadow-md"
              />
              <div className="bg-white p-6 rounded-xl shadow-md space-y-4">
                <div className="flex items-center gap-4">
                  <span className="text-blue-600 text-2xl">📧</span>
                  <p className="text-gray-700">mounikamtala@gmail.com</p>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-blue-600 text-2xl">📞</span>
                  <p className="text-gray-700">+91 6303332010</p>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-blue-600 text-2xl">📍</span>
                  <p className="text-gray-700">Hyderabad, India</p>
                </div>
              </div>
            </div>

            {/* Right: Contact Form */}
            <form onSubmit={handleSubmit} className="bg-white p-6 sm:p-8 rounded-xl shadow-lg space-y-6 w-full">
              <div>
                <label className="block text-left text-gray-700 font-semibold mb-2">Your Name</label>
                <input
                  type="text"
                  name="name"
                  placeholder="Enter your name"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full border text-black border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-left text-gray-700 font-semibold mb-2">Your Email</label>
                <input
                  type="email"
                  name="email"
                  placeholder="Enter your email"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full border text-black border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-left text-gray-700 font-semibold mb-2">Message</label>
                <textarea
                  name="message"
                  placeholder="Write your message"
                  rows="4"
                  value={formData.message}
                  onChange={handleChange}
                  className="w-full border text-black border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 outline-none"
                ></textarea>
              </div>

              {error && <p className="text-red-500 text-center">{error}</p>}
              {success && <p className="text-green-600 text-center">{success}</p>}

              <button
                type="submit"
                className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-all shadow-md"
              >
                Send Message
              </button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
