

import React from "react";
import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import { Toaster } from "react-hot-toast";

// Public Pages
import Home from "./Home/Home";
import Navbar from "./Home/Navbar";
import About from "./Home/About";
import Contact from "./Home/Contact";
import Footer from "./Home/Footer";
import Login from "./Auth/Login";
import Signup from "./Auth/Signup";
import ForgotPassword from "./Auth/ForgotPw";

//Admin Dashboard Pages
import SuperAdminLayout from "./Components/Dashboard/SuperAdminLayout";
import SummaryCards from "./Pages/Cards";
import Clients from "./Pages/Client";
import Employees from "./Pages/Employee";
import Invoices from "./Pages/Invoice";
import Projects from "./Pages/Projects";
import Notification from "./Pages/Notification";
import Profile from "./Pages/Profile";
import Manager from "./Pages/Manager";

// Client Dashboard Pages
import Dashboard from "./Components/Client/Dashboard";
import Summary from "./Components/Client/Summary";
import ClientInvoices from "./Components/Client/ClientInvoices";
import Payments from "./Components/Client/Payments";
import ClientProfile from "./Components/Client/ClientProfile";



// Employee Dashboard pages
import EmployeeDashboard from "./Components/Employee/EmployeeDashboard";
import EmProjects from "./Components/Employee/EmProjects";
import Teamleads from "./Components/Employee/Teamleads";
import EmpProfile from "./Components/Employee/EmpProfile";


// Team lead Dashboard Pages
import TeamleadDashboard from "./Components/Teamlead/TeamleadDashboard"; 
import TeamProjects from "./Components/Teamlead/TeamProjects";
import TeamEmployees from "./Components/Teamlead/TeamEmployees";
import TeamProfile from "./Components/Teamlead/TeamProfile";


function AppContent() {
  const location = useLocation();

  // Public paths: Navbar & Footer will show only here
  const publicPaths = ["/", "/about", "/contact", "/login", "/signup", "/forgot-password"];
  const showPublicLayout = publicPaths.includes(location.pathname);

  return (
    <>
      {/* Toaster for notifications */}
      <Toaster position="top-center" reverseOrder={false} />

      {/* Navbar for public pages */}
      {showPublicLayout && <Navbar />}

      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />

        {/* Dashboard Routes */}
        <Route path="/admin-dashboard" element={<SuperAdminLayout />}>
          <Route path="summary" element={<SummaryCards />} />
          <Route path="clients" element={<Clients />} />
          <Route path="employees" element={<Employees />} />
          <Route path="managers" element={<Manager />} />
          <Route path="invoices" element={<Invoices />} />
          <Route path="projects" element={<Projects />} />
          <Route path="notification" element={<Notification />} />
          <Route path="profile" element={<Profile />} />
        </Route>
           

           <Route path="/client-dashboard" element={<Dashboard />}>
           <Route path="client-profile" element={<ClientProfile />} />

  <Route path="summary" element={<Summary />} />
  <Route path="client-invoices" element={<ClientInvoices />} />  
  <Route path="payments" element={<Payments />} />
  <Route path="project" element={<Projects />} />  {/* ✅ plural */}
    {/* <Route path="client-profile" element={<ClientProfile />} /> */}

</Route>

            <Route path="/employee-dashboard" element={<EmployeeDashboard/>}></Route>
             <Route path="/emprojects" element={<EmProjects />} />
             <Route path="teamleads" element={<Teamleads />} />
              <Route path="/empProfile" element={<EmpProfile />} />


           <Route path="/Teamlead-Dashboard" element={<TeamleadDashboard />} />
             <Route path="/teamProjects" element={<TeamProjects />} />
             <Route path="/teamEmployees" element={<TeamEmployees />} />
             <Route path="/teamProfile" element={<TeamProfile />} />


      </Routes>

     

       

      {/* Footer for public pages */}
      {showPublicLayout && <Footer />}
    </>
  );
}

export default function App() {
  return (
    <Router>
       {/* ✅ Global toaster (works on all pages) */}
      <Toaster position="top-center" reverseOrder={false} />
      <AppContent />
    </Router>
  );
}