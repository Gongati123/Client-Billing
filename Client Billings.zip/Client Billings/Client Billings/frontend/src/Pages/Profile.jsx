import React, { useState } from "react";
import { FaUser, FaEnvelope, FaPhone, FaLock, FaCamera } from "react-icons/fa";
import { Eye, EyeOff } from "lucide-react";

export default function Profile() {
  const [profile, setProfile] = useState({
    name: "Mounika Kamatala",
    email: "mouni@gmail.com",
    contact: "6303332010",
    role: " Admin",
    profilePic: "/Images/Me.jpeg",
  });

  const [editMode, setEditMode] = useState(false);
  const [showPasswords, setShowPasswords] = useState({
    currentPassword: false,
    newPassword: false,
    confirmPassword: false,
  });
  const [passwords, setPasswords] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [errors, setErrors] = useState({});

  // Handle profile field changes
  const handleChange = (e) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
  };

  // Handle password field changes
  const handlePasswordChange = (e) => {
    setPasswords({ ...passwords, [e.target.name]: e.target.value });
  };

  // Handle profile picture upload
  const handleProfilePicChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      setProfile({ ...profile, profilePic: imageUrl });
    }
  };

  const handleSave = () => {
    alert("✅ Profile Updated Successfully!");
    setEditMode(false);
  };

  const handlePasswordUpdate = () => {
    let newErrors = {};
    if (!passwords.currentPassword) newErrors.currentPassword = "Please fill this field";
    if (!passwords.newPassword) newErrors.newPassword = "Please fill this field";
    if (!passwords.confirmPassword) newErrors.confirmPassword = "Please fill this field";
    if (passwords.newPassword && passwords.confirmPassword && passwords.newPassword !== passwords.confirmPassword) {
      newErrors.confirmPassword = "Passwords do not match!";
    }

    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      alert("🔐 Password Changed Successfully!");
      setPasswords({ currentPassword: "", newPassword: "", confirmPassword: "" });
    }
  };

  return (
    <div className="p-8 bg-gray-50 min-h-screen">
      <h2 className="text-2xl font-semibold text-gray-800 mb-6">Profile Settings</h2>

      <div className="bg-white rounded-2xl shadow-lg p-8 max-w-3xl mx-auto">
        {/* Profile Picture */}
        <div className="flex flex-col items-center mb-8 relative">
          <img
            src={profile.profilePic}
            alt="Profile"
            className="w-28 h-28 rounded-full border-4 border-blue-500 object-cover"
          />
          {editMode && (
            <label
              htmlFor="profilePic"
              className="absolute bottom-0 right-[43%] bg-blue-600 text-white p-2 rounded-full cursor-pointer hover:bg-blue-700"
            >
              <FaCamera size={16} />
              <input
                type="file"
                id="profilePic"
                accept="image/*"
                onChange={handleProfilePicChange}
                className="hidden"
              />
            </label>
          )}
          <h3 className="text-xl font-semibold mt-4">{profile.name}</h3>
          <p className="text-gray-600">{profile.role}</p>
        </div>

        {/* Personal Info Section */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-gray-700 mb-4 flex items-center gap-2">
            <FaUser /> Personal Information
          </h3>

          <div className="space-y-4">
            {/* Name */}
            <div>
              <label className="block text-gray-600 mb-1">Full Name</label>
              <input
                type="text"
                name="name"
                value={profile.name}
                onChange={handleChange}
                disabled={!editMode}
                className={`w-full px-4 py-2 border rounded-lg focus:outline-none ${
                  editMode ? "border-blue-400" : "bg-gray-100"
                }`}
              />
            </div>

            {/* Email */}
            <div>
              <label className="block text-gray-600 mb-1">Email</label>
              <input
                type="email"
                name="email"
                value={profile.email}
                onChange={handleChange}
                disabled={!editMode}
                className={`w-full px-4 py-2 border rounded-lg focus:outline-none ${
                  editMode ? "border-blue-400" : "bg-gray-100"
                }`}
              />
            </div>

            {/* Contact */}
            <div>
              <label className="block text-gray-600 mb-1">Contact</label>
              <div className="flex items-center">
                <FaPhone className="text-gray-500 mr-2" />
                <input
                  type="text"
                  name="contact"
                  value={profile.contact}
                  onChange={handleChange}
                  disabled={!editMode}
                  className={`w-full px-4 py-2 border rounded-lg focus:outline-none ${
                    editMode ? "border-blue-400" : "bg-gray-100"
                  }`}
                />
              </div>
            </div>
          </div>

          <div className="mt-6 flex justify-end gap-4">
            {editMode ? (
              <>
                <button
                  onClick={handleSave}
                  className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700"
                >
                  Save
                </button>
                <button
                  onClick={() => setEditMode(false)}
                  className="bg-gray-400 text-white px-4 py-2 rounded-lg hover:bg-gray-500"
                >
                  Cancel
                </button>
              </>
            ) : (
              <button
                onClick={() => setEditMode(true)}
                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
              >
                Edit Profile
              </button>
            )}
          </div>
        </div>

        <hr className="my-6 border-gray-300" />

        {/* Password Section */}
        <div>
          <h3 className="text-lg font-semibold text-gray-700 mb-4 flex items-center gap-2">
            <FaLock /> Change Password
          </h3>

          <div className="space-y-4">
            {/* Current Password */}
            <div>
              <label className="block text-gray-600 mb-1">Current Password</label>
              <div className="relative">
                <input
                  type={showPasswords.currentPassword ? "text" : "password"}
                  name="currentPassword"
                  value={passwords.currentPassword}
                  onChange={handlePasswordChange}
                  className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-400 pr-10"
                  placeholder="Enter current password"
                />
                <span
                  className="absolute inset-y-0 right-3 flex items-center cursor-pointer text-gray-500"
                  onClick={() =>
                    setShowPasswords((prev) => ({
                      ...prev,
                      currentPassword: !prev.currentPassword,
                    }))
                  }
                >
                  {showPasswords.currentPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </span>
              </div>
              {errors.currentPassword && (
                <p className="text-red-500 text-sm mt-1">{errors.currentPassword}</p>
              )}
            </div>

            {/* New Password */}
            <div>
              <label className="block text-gray-600 mb-1">New Password</label>
              <div className="relative">
                <input
                  type={showPasswords.newPassword ? "text" : "password"}
                  name="newPassword"
                  value={passwords.newPassword}
                  onChange={handlePasswordChange}
                  className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-400 pr-10"
                  placeholder="Enter new password"
                />
                <span
                  className="absolute inset-y-0 right-3 flex items-center cursor-pointer text-gray-500"
                  onClick={() =>
                    setShowPasswords((prev) => ({
                      ...prev,
                      newPassword: !prev.newPassword,
                    }))
                  }
                >
                  {showPasswords.newPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </span>
              </div>
              {errors.newPassword && (
                <p className="text-red-500 text-sm mt-1">{errors.newPassword}</p>
              )}
            </div>

            {/* Confirm Password */}
            <div>
              <label className="block text-gray-600 mb-1">Confirm Password</label>
              <div className="relative">
                <input
                  type={showPasswords.confirmPassword ? "text" : "password"}
                  name="confirmPassword"
                  value={passwords.confirmPassword}
                  onChange={handlePasswordChange}
                  className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-400 pr-10"
                  placeholder="Confirm new password"
                />
                <span
                  className="absolute inset-y-0 right-3 flex items-center cursor-pointer text-gray-500"
                  onClick={() =>
                    setShowPasswords((prev) => ({
                      ...prev,
                      confirmPassword: !prev.confirmPassword,
                    }))
                  }
                >
                  {showPasswords.confirmPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </span>
              </div>
              {errors.confirmPassword && (
                <p className="text-red-500 text-sm mt-1">{errors.confirmPassword}</p>
              )}
            </div>
          </div>

          <div className="mt-6 flex justify-end">
            <button
              onClick={handlePasswordUpdate}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
            >
              Update Password
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
