import React, { useState, useEffect } from "react";
import { FaPlus, FaEdit, FaTrashAlt, FaFolderOpen, FaSearch } from "react-icons/fa";
import { toast } from "react-hot-toast";

const Projects = () => {
  const [projects, setProjects] = useState([]);
  const [filteredProjects, setFilteredProjects] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [editProjectId, setEditProjectId] = useState(null);
  const [formData, setFormData] = useState({
    projectId: "",
    clientId: "",
    projectName: "",
    billingRate: "",
    startDate: "",
    endDate: "",
  });
  const [showModal, setShowModal] = useState(false);

  // 🟢 Fetch projects from backend
  useEffect(() => {
    fetch("http://localhost:8080/projects")
      .then((res) => {
        if (!res.ok) throw new Error("Failed to fetch projects");
        return res.json();
      })
      .then((data) => {
        setProjects(data);
        setFilteredProjects(data);
        toast.success("✅ Projects loaded successfully!");
      })
      // .catch(() => toast.error("⚠️ Unable to connect to backend!"));
  }, []);

  // 🔹 Handle Search
  useEffect(() => {
    const filtered = projects.filter(
      (proj) =>
        proj.projectName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        proj.projectId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        proj.clientId?.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredProjects(filtered);
  }, [searchTerm, projects]);

  // 🔹 Handle Input Change
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // 🔹 Edit Project
  const handleEdit = (proj) => {
    setEditProjectId(proj.id);
    setFormData(proj);
    setShowModal(true);
  };

  // 🔹 Save Edited Project
  const handleSave = (e) => {
    e.preventDefault();
    const updated = projects.map((p) =>
      p.id === editProjectId ? { ...formData } : p
    );
    setProjects(updated);
    setEditProjectId(null);
    setShowModal(false);
    toast.success("✅ Project updated successfully!");
  };

  // 🔹 Add New Project
  const handleAddProject = (e) => {
    e.preventDefault();

    if (
      !formData.projectId ||
      !formData.clientId ||
      !formData.projectName ||
      !formData.billingRate ||
      !formData.startDate ||
      !formData.endDate
    ) {
      toast.error("⚠️ Please fill all required fields!");
      return;
    }

    const newProject = { ...formData, id: Date.now() };
    const newList = [...projects, newProject];
    setProjects(newList);
    setFilteredProjects(newList);
    setShowModal(false);
    toast.success("🎉 Project added successfully!");
  };

  // 🔹 Delete Project
  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this project?")) {
      const updated = projects.filter((p) => p.id !== id);
      setProjects(updated);
      setFilteredProjects(updated);
      toast.success("🗑️ Project deleted successfully!");
    } else {
      toast("❌ Deletion cancelled");
    }
  };

  return (
    <div className="p-4 sm:p-6 bg-gray-50 min-h-screen">
      {/* 🔵 Header Section */}
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-6 gap-3">
        <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
          <FaFolderOpen /> Projects
        </h2>
         <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
        {/* 🔍 Search Bar */}
        <div className="flex items-center bg-white border border-gray-300 rounded-lg shadow-sm w-full sm:w-80 px-3 py-2">
          <FaSearch className="text-gray-500 mr-2" />
          <input
            type="text"
            placeholder="Search by Project ID, Name or Client ID"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full outline-none text-sm bg-transparent"
          />
        </div>

        {/* ➕ Add Project Button */}
        <button
          onClick={() => {
            setShowModal(true);
            setEditProjectId(null);
            setFormData({
              projectId: "",
              clientId: "",
              projectName: "",
              billingRate: "",
              startDate: "",
              endDate: "",
            });
          }}
          className="flex items-center justify-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition w-full sm:w-auto"
        >
          <FaPlus /> Add Project
        </button>
      </div>
      </div>

      {/* ✅ Desktop Table View */}
      <div className="hidden md:block overflow-x-auto bg-white shadow-md rounded-xl">
        <table className="min-w-full border-collapse">
          <thead>
            <tr className="bg-blue-100 text-gray-800">
              <th className="py-3 px-4 text-center">S.No</th>
              <th className="py-3 px-4 text-left">Project ID</th>
              <th className="py-3 px-4 text-left">Client ID</th>
              <th className="py-3 px-4 text-left">Project Name</th>
              <th className="py-3 px-4 text-center">Billing Rate</th>
              <th className="py-3 px-4 text-center">Start Date</th>
              <th className="py-3 px-4 text-center">End Date</th>
              <th className="py-3 px-4 text-center">Actions</th>
            </tr>
          </thead>

          <tbody>
            {filteredProjects.length > 0 ? (
              filteredProjects.map((proj, index) => (
                <tr
                  key={proj.id || index}
                  className="border-t hover:bg-blue-50 transition"
                >
                  <td className="py-3 px-4 text-center">{index + 1}</td>
                  <td className="py-3 px-4">{proj.projectId}</td>
                  <td className="py-3 px-4">{proj.clientId}</td>
                  <td className="py-3 px-4 font-medium">{proj.projectName}</td>
                  <td className="py-3 px-4 text-center">₹{proj.billingRate}</td>
                  <td className="py-3 px-4 text-center">{proj.startDate}</td>
                  <td className="py-3 px-4 text-center">{proj.endDate}</td>
                  <td className="py-3 px-4 text-center">
                    <div className="flex justify-center gap-3 text-lg">
                      <button
                        className="text-blue-600 hover:text-blue-800"
                        onClick={() => handleEdit(proj)}
                      >
                        <FaEdit />
                      </button>
                      <button
                        className="text-red-600 hover:text-red-800"
                        onClick={() => handleDelete(proj.id)}
                      >
                        <FaTrashAlt />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="8" className="text-center py-6 text-gray-500">
                  No projects found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* ✅ Mobile View */}
      <div className="md:hidden grid gap-4">
        {filteredProjects.length > 0 ? (
          filteredProjects.map((proj, index) => (
            <div
              key={proj.id || index}
              className="bg-white shadow-md rounded-lg p-4 border border-gray-200"
            >
              <div className="flex justify-between mb-2">
                <h3 className="font-semibold text-lg text-gray-800">
                  {proj.projectName}
                </h3>
                <span className="text-sm text-gray-500">#{index + 1}</span>
              </div>
              <p className="text-sm text-gray-600">
                <strong>Project ID:</strong> {proj.projectId}
              </p>
              <p className="text-sm text-gray-600">
                <strong>Client ID:</strong> {proj.clientId}
              </p>
              <p className="text-sm text-gray-600">
                <strong>Billing Rate:</strong> ₹{proj.billingRate}
              </p>
              <p className="text-sm text-gray-600">
                <strong>Start Date:</strong> {proj.startDate}
              </p>
              <p className="text-sm text-gray-600 mb-3">
                <strong>End Date:</strong> {proj.endDate}
              </p>

              <div className="flex justify-end gap-4 text-lg">
                <button
                  className="text-blue-600 hover:text-blue-800"
                  onClick={() => handleEdit(proj)}
                >
                  <FaEdit />
                </button>
                <button
                  className="text-red-600 hover:text-red-800"
                  onClick={() => handleDelete(proj.id)}
                >
                  <FaTrashAlt />
                </button>
              </div>
            </div>
          ))
        ) : (
          <p className="text-center text-gray-500">No projects found.</p>
        )}
      </div>

      {/* 🔵 Modal for Add/Edit */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-11/12 max-w-md shadow-xl">
            <h3 className="text-xl font-semibold mb-4 text-gray-800 text-center">
              {editProjectId ? "Edit Project" : "Add Project"}
            </h3>

            <form onSubmit={editProjectId ? handleSave : handleAddProject}>
              <div className="space-y-3">
                <input
                  type="text"
                  name="projectId"
                  value={formData.projectId}
                  onChange={handleChange}
                  placeholder="Project ID"
                  className="border p-2 w-full rounded"
                />
                <input
                  type="text"
                  name="clientId"
                  value={formData.clientId}
                  onChange={handleChange}
                  placeholder="Client ID"
                  className="border p-2 w-full rounded"
                />
                <input
                  type="text"
                  name="projectName"
                  value={formData.projectName}
                  onChange={handleChange}
                  placeholder="Project Name"
                  className="border p-2 w-full rounded"
                />
                <input
                  type="number"
                  name="billingRate"
                  value={formData.billingRate}
                  onChange={handleChange}
                  placeholder="Billing Rate"
                  className="border p-2 w-full rounded"
                />
                <input
                  type="date"
                  name="startDate"
                  value={formData.startDate}
                  onChange={handleChange}
                  className="border p-2 w-full rounded"
                />
                <input
                  type="date"
                  name="endDate"
                  value={formData.endDate}
                  onChange={handleChange}
                  className="border p-2 w-full rounded"
                />
              </div>

              <div className="mt-5 flex justify-end gap-3">
                <button
                  type="button"
                  className="px-4 py-2 rounded bg-gray-300 hover:bg-gray-400"
                  onClick={() => setShowModal(false)}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded bg-blue-600 hover:bg-blue-700 text-white"
                >
                  {editProjectId ? "Save" : "Add"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Projects;
