import React, { useState, useEffect } from "react";
import {
  FaPlus,
  FaTrashAlt,
  FaFileInvoice,
  FaDownload,
  FaSearch,
  FaEye,
} from "react-icons/fa";
import { jsPDF } from "jspdf";
import toast from "react-hot-toast";

const Invoices = () => {
  const [invoices, setInvoices] = useState([]);
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [viewInvoice, setViewInvoice] = useState(null);
  const [formData, setFormData] = useState({
    invoiceId: "",
    clientId: "",
    projectId: "",
    month: "",
    totalHours: "",
    billingRate: "",
    netAmount: "",
  });

  // ✅ Load invoices from localStorage
  useEffect(() => {
    const saved = JSON.parse(localStorage.getItem("invoices"));
    if (saved && saved.length > 0) setInvoices(saved);
  }, []);

  // ✅ Save invoices to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("invoices", JSON.stringify(invoices));
  }, [invoices]);

  // ✅ Handle input change and auto-calculate netAmount
  const handleChange = (e) => {
    const { name, value } = e.target;
    const updated = { ...formData, [name]: value };
    if (name === "totalHours" || name === "billingRate") {
      const hours = name === "totalHours" ? value : formData.totalHours;
      const rate = name === "billingRate" ? value : formData.billingRate;
      updated.netAmount = (hours * rate).toFixed(2);
    }
    setFormData(updated);
  };

  // ✅ Add invoice
  const handleAdd = (e) => {
    e.preventDefault();
    if (
      !formData.invoiceId ||
      !formData.clientId ||
      !formData.projectId ||
      !formData.totalHours ||
      !formData.billingRate
    ) {
      toast.error("⚠️ Please fill all required fields!");
      return;
    }

    const newInvoice = {
      ...formData,
      id: Date.now(),
      netAmount: (formData.totalHours * formData.billingRate).toFixed(2),
    };
    setInvoices([...invoices, newInvoice]);
    setShowModal(false);
    toast.success("✅ Invoice added successfully!");

    setFormData({
      invoiceId: "",
      clientId: "",
      projectId: "",
      month: "",
      totalHours: "",
      billingRate: "",
      netAmount: "",
    });
  };

  // ✅ Delete invoice
  const handleDelete = (id) => {
    if (window.confirm("Delete this invoice?")) {
      setInvoices(invoices.filter((inv) => inv.id !== id));
      toast.success("🗑️ Invoice deleted successfully!");
    }
  };

  // ✅ View invoice details
  const handleView = (invoice) => setViewInvoice(invoice);

  // ✅ Download invoice as PDF
  const handleDownload = (invoice) => {
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text("Invoice Details", 20, 20);
    doc.setFontSize(12);
    doc.text(`Invoice ID: ${invoice.invoiceId}`, 20, 40);
    doc.text(`Client ID: ${invoice.clientId}`, 20, 50);
    doc.text(`Project ID: ${invoice.projectId}`, 20, 60);
    doc.text(`Month: ${invoice.month}`, 20, 70);
    doc.text(`Total Hours: ${invoice.totalHours}`, 20, 80);
    doc.text(`Billing Rate: ₹${invoice.billingRate}`, 20, 90);
    doc.text(`Net Amount: ₹${invoice.netAmount}`, 20, 100);
    doc.save(`Invoice_${invoice.invoiceId}.pdf`);

    toast.success("📄 Invoice downloaded!");
  };

  // ✅ Filter invoices based on search
  const filteredInvoices = invoices.filter(
    (inv) =>
      inv.invoiceId.toLowerCase().includes(search.toLowerCase()) ||
      inv.clientId.toLowerCase().includes(search.toLowerCase()) ||
      inv.projectId.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-4 sm:p-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-center gap-3 mb-6">
        <h2 className="text-2xl sm:text-3xl font-bold text-gray-800 flex items-center gap-2">
          <FaFileInvoice /> Invoices
        </h2>
        <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
       <div className="relative w-full sm:w-64">
          <FaSearch className="absolute top-3 left-3 text-gray-500" />
          <input
            type="text"
            placeholder="Search invoice..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full border border-gray-300 rounded-lg pl-10 pr-3 py-2 focus:ring-2 focus:ring-blue-400 focus:outline-none"
          />
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center justify-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm sm:text-base w-full sm:w-auto"
        >
          <FaPlus /> Add Invoice
        </button>
      </div>
      </div>

      {/* Desktop Table */}
      <div className="hidden md:block overflow-x-auto bg-white shadow-md rounded-xl">
        <table className="min-w-full text-sm sm:text-base border-collapse">
          <thead>
            <tr className="bg-blue-100 text-gray-800">
              <th className="py-3 px-4 text-left">Invoice ID</th>
              <th className="py-3 px-4 text-left">Client ID</th>
              <th className="py-3 px-4 text-left">Project ID</th>
              <th className="py-3 px-4 text-center">Month</th>
              <th className="py-3 px-4 text-center">Hours</th>
              <th className="py-3 px-4 text-center">Rate</th>
              <th className="py-3 px-4 text-center">Net</th>
              <th className="py-3 px-4 text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredInvoices.length > 0 ? (
              filteredInvoices.map((inv) => (
                <tr
                  key={inv.id}
                  className="border-t hover:bg-blue-50 transition text-gray-700"
                >
                  <td className="py-3 px-4">{inv.invoiceId}</td>
                  <td className="py-3 px-4">{inv.clientId}</td>
                  <td className="py-3 px-4">{inv.projectId}</td>
                  <td className="py-3 px-4 text-center">{inv.month}</td>
                  <td className="py-3 px-4 text-center">{inv.totalHours}</td>
                  <td className="py-3 px-4 text-center">₹{inv.billingRate}</td>
                  <td className="py-3 px-4 text-center font-semibold text-green-600">
                    ₹{inv.netAmount}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <div className="flex justify-center gap-3 text-lg">
                      <button
                        className="text-green-600 hover:text-green-800"
                        onClick={() => handleView(inv)}
                        title="View"
                      >
                        <FaEye />
                      </button>
                      <button
                        className="text-blue-600 hover:text-blue-800"
                        onClick={() => handleDownload(inv)}
                        title="Download"
                      >
                        <FaDownload />
                      </button>
                      <button
                        className="text-red-600 hover:text-red-800"
                        onClick={() => handleDelete(inv.id)}
                        title="Delete"
                      >
                        <FaTrashAlt />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td
                  colSpan="8"
                  className="text-center py-6 text-gray-500 font-medium"
                >
                  No invoices found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Mobile Card View */}
      <div className="md:hidden grid grid-cols-1 gap-4">
        {filteredInvoices.length > 0 ? (
          filteredInvoices.map((inv) => (
            <div
              key={inv.id}
              className="bg-white shadow-md rounded-lg p-4 border border-gray-200"
            >
              <div className="flex justify-between items-center mb-2">
                <h3 className="font-semibold text-lg text-gray-800">
                  {inv.invoiceId}
                </h3>
                <span className="text-green-600 font-semibold">
                  ₹{inv.netAmount}
                </span>
              </div>
              <p className="text-sm text-gray-700">
                <strong>Client:</strong> {inv.clientId}
              </p>
              <p className="text-sm text-gray-700">
                <strong>Project:</strong> {inv.projectId}
              </p>
              <p className="text-sm text-gray-700">
                <strong>Month:</strong> {inv.month}
              </p>
              <p className="text-sm text-gray-700">
                <strong>Hours:</strong> {inv.totalHours} |{" "}
                <strong>Rate:</strong> ₹{inv.billingRate}
              </p>

              <div className="flex justify-end gap-3 mt-3">
                <button
                  className="text-green-600 hover:text-green-800"
                  onClick={() => handleView(inv)}
                >
                  <FaEye />
                </button>
                <button
                  className="text-blue-600 hover:text-blue-800"
                  onClick={() => handleDownload(inv)}
                >
                  <FaDownload />
                </button>
                <button
                  className="text-red-600 hover:text-red-800"
                  onClick={() => handleDelete(inv.id)}
                >
                  <FaTrashAlt />
                </button>
              </div>
            </div>
          ))
        ) : (
          <p className="text-center text-gray-500">No invoices found</p>
        )}
      </div>

      {/* Add Invoice Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center px-4 z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-sm sm:max-w-md shadow-lg">
            <h3 className="text-lg sm:text-xl font-bold mb-4 text-center">
              Add New Invoice
            </h3>
            <form onSubmit={handleAdd} className="space-y-3">
              {[
                { name: "invoiceId", placeholder: "Invoice ID" },
                { name: "clientId", placeholder: "Client ID" },
                { name: "projectId", placeholder: "Project ID" },
                { name: "month", placeholder: "Month (e.g., Oct 2025)" },
              ].map((f) => (
                <input
                  key={f.name}
                  type="text"
                  name={f.name}
                  placeholder={f.placeholder}
                  value={formData[f.name]}
                  onChange={handleChange}
                  className="border p-2 w-full rounded focus:ring-2 focus:ring-blue-400 outline-none"
                />
              ))}

              <input
                type="number"
                name="totalHours"
                placeholder="Total Hours"
                value={formData.totalHours}
                onChange={handleChange}
                className="border p-2 w-full rounded focus:ring-2 focus:ring-blue-400 outline-none"
              />
              <input
                type="number"
                name="billingRate"
                placeholder="Billing Rate"
                value={formData.billingRate}
                onChange={handleChange}
                className="border p-2 w-full rounded focus:ring-2 focus:ring-blue-400 outline-none"
              />

              <div className="flex flex-col sm:flex-row justify-between gap-3 mt-4">
                <button
                  type="submit"
                  className="w-full sm:w-auto bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
                >
                  Add
                </button>
                <button
                  type="button"
                  className="w-full sm:w-auto bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
                  onClick={() => setShowModal(false)}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Invoice Modal */}
      {viewInvoice && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center px-4 z-50">
          <div className="bg-white p-6 rounded-lg w-full max-w-sm sm:max-w-md shadow-lg">
            <h3 className="text-lg sm:text-xl font-bold mb-4 text-center">
              Invoice Details
            </h3>
            <div className="space-y-2 text-gray-700 text-sm sm:text-base">
              <p><strong>Invoice ID:</strong> {viewInvoice.invoiceId}</p>
              <p><strong>Client ID:</strong> {viewInvoice.clientId}</p>
              <p><strong>Project ID:</strong> {viewInvoice.projectId}</p>
              <p><strong>Month:</strong> {viewInvoice.month}</p>
              <p><strong>Total Hours:</strong> {viewInvoice.totalHours}</p>
              <p><strong>Billing Rate:</strong> ₹{viewInvoice.billingRate}</p>
              <p className="font-semibold text-green-600">
                <strong>Net Amount:</strong> ₹{viewInvoice.netAmount}
              </p>
            </div>
            <div className="mt-5 flex justify-center">
              <button
                className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                onClick={() => setViewInvoice(null)}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Invoices;
