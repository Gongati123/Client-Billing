



import React, { useState, useEffect } from "react";
import { FaUserPlus, FaSearch, FaBuilding, FaEdit, FaTrash } from "react-icons/fa";
import toast from "react-hot-toast";
import clientsData from "./ClientsData.json"; // Your local JSON

const Clients = () => {
  const [clients, setClients] = useState([]);
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [selectedClient, setSelectedClient] = useState(null);
  const [newClient, setNewClient] = useState({
    clientId: "",
    email: "",
    company: "",
    address: "",
  });

  useEffect(() => {
    setClients(clientsData);
  }, []);

  // Open modal
  const handleOpenModal = (client = null) => {
    if (client) {
      setEditMode(true);
      setSelectedClient(client);
      setNewClient(client);
    } else {
      setEditMode(false);
      setSelectedClient(null);
      setNewClient({ clientId: "", email: "", company: "", address: "" });
    }
    setShowModal(true);
  };

  // Save client
  const handleSaveClient = (e) => {
    e.preventDefault();

    if (!newClient.clientId || !newClient.email || !newClient.company || !newClient.address) {
      toast.error("⚠️ Please fill all required fields!");
      return;
    }

    if (editMode) {
      setClients((prev) =>
        prev.map((c) => (c.id === selectedClient.id ? { ...newClient, id: selectedClient.id } : c))
      );
      toast.success("✏️ Client updated successfully!");
    } else {
      setClients([...clients, { id: Date.now(), ...newClient }]);
      toast.success("✅ Client added successfully!");
    }

    setShowModal(false);
    setEditMode(false);
    setSelectedClient(null);
  };

  // Delete client
  const handleDeleteClient = (id) => {
    setClients(clients.filter((c) => c.id !== id));
    toast.success("🗑️ Client deleted successfully!");
  };

  const filteredClients = clients.filter(
    (c) =>
      c.clientId.toLowerCase().includes(search.toLowerCase()) ||
      c.company.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-4 sm:p-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
        <h2 className="text-2xl sm:text-3xl font-bold text-gray-800">Clients</h2>
        <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:flex-none">
            <input
              type="text"
              placeholder="Search by ID or company..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="border border-gray-300 rounded-lg pl-10 pr-3 py-2 w-full focus:ring-2 focus:ring-blue-400 focus:outline-none"
            />
            <FaSearch className="absolute top-3 left-3 text-gray-500" />
          </div>
          <button
            onClick={() => handleOpenModal()}
            className="flex items-center justify-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition text-sm sm:text-base"
          >
            <FaUserPlus /> Add Client
          </button>
        </div>
      </div>

      {/* Desktop Table */}
      <div className="hidden md:block overflow-x-auto bg-white shadow-lg rounded-xl">
        <table className="min-w-full border-collapse text-sm sm:text-base">
          <thead>
            <tr className="bg-blue-100 text-gray-800">
              <th className="py-3 px-4 text-center font-semibold">S.No</th>
              <th className="py-3 px-4 text-left font-semibold">Client ID</th>
              <th className="py-3 px-4 text-left font-semibold">Email</th>
              <th className="py-3 px-4 text-left font-semibold">Company</th>
              <th className="py-3 px-4 text-left font-semibold">Address</th>
              <th className="py-3 px-4 text-center font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredClients.map((client, index) => (
              <tr key={client.id} className="border-t hover:bg-blue-50 transition text-gray-700">
                <td className="py-3 px-4 text-center">{index + 1}</td>
                <td className="py-3 px-4">{client.clientId}</td>
                <td className="py-3 px-4">{client.email}</td>
                <td className="py-3 px-4 flex items-center gap-2">
                  <FaBuilding className="text-gray-500" /> {client.company}
                </td>
                <td className="py-3 px-4">{client.address}</td>
                <td className="py-3 px-4 text-center flex justify-center gap-3">
                  <button onClick={() => handleOpenModal(client)} className="text-blue-600 hover:text-blue-800"><FaEdit /></button>
                  <button onClick={() => handleDeleteClient(client.id)} className="text-red-600 hover:text-red-800"><FaTrash /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile Cards */}
      <div className="md:hidden flex flex-col gap-4">
        {filteredClients.map((client, index) => (
          <div key={client.id} className="bg-white p-4 rounded-xl shadow hover:shadow-lg transition">
            <div className="flex justify-between mb-2">
              <span className="font-semibold">#{index + 1}</span>
              <div className="flex gap-2">
                <button onClick={() => handleOpenModal(client)} className="text-blue-600 hover:text-blue-800"><FaEdit /></button>
                <button onClick={() => handleDeleteClient(client.id)} className="text-red-600 hover:text-red-800"><FaTrash /></button>
              </div>
            </div>
            <div className="space-y-1 text-gray-700">
              <p><strong>ID:</strong> {client.clientId}</p>
              <p><strong>Email:</strong> {client.email}</p>
              <p className="flex items-center gap-1"><FaBuilding className="text-gray-500" /> {client.company}</p>
              <p><strong>Address:</strong> {client.address}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-40 px-4">
          <div className="bg-white rounded-xl shadow-lg p-6 w-full max-w-sm sm:max-w-md">
            <h3 className="text-xl font-semibold mb-4 text-gray-800 text-center">
              {editMode ? "Edit Client" : "Add New Client"}
            </h3>
            <form onSubmit={handleSaveClient} className="space-y-3">
              {["clientId", "email", "company", "address"].map((field) => (
                <input
                  key={field}
                  type={field === "email" ? "email" : "text"}
                  placeholder={field.charAt(0).toUpperCase() + field.slice(1)}
                  value={newClient[field]}
                  onChange={(e) => setNewClient({ ...newClient, [field]: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-400 focus:outline-none"
                />
              ))}
              <div className="flex flex-col sm:flex-row justify-end gap-3 mt-4">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="w-full sm:w-auto bg-gray-400 text-white px-4 py-2 rounded-lg hover:bg-gray-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-full sm:w-auto bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                >
                  {editMode ? "Update" : "Save"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Clients;
