// import React from "react";
// import { FaProjectDiagram, FaFileInvoiceDollar, FaCheckCircle, FaExclamationCircle } from "react-icons/fa";


// const SummaryCards = () => {
//   // Dummy data (replace with real API data)
//   const summaryData = [
//     {
//       title: "Active Projects",
//       value: 12,
//       icon: <FaProjectDiagram className="text-blue-500 text-3xl " />,
//       bgColor: "bg-blue-100",
//     },
//     {
//       title: "Total Invoices",
//       value: 45,
//       icon: <FaFileInvoiceDollar className="text-yellow-500 text-3xl" />,
//       bgColor: "bg-yellow-100",
//     },
//     {
//       title: "Paid Invoices",
//       value: 30,
//       icon: <FaCheckCircle className="text-green-500 text-3xl" />,
//       bgColor: "bg-green-100",
//     },
//     {
//       title: "Pending Invoices",
//       value: 15,
//       icon: <FaExclamationCircle className="text-red-500 text-3xl" />,
//       bgColor: "bg-red-100",
//     },
//   ];

//   return (
//     <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 p-4">
//       {summaryData.map((card, index) => (
//         <div
//           key={index}
//           className={`flex items-center p-4 rounded-xl shadow-md ${card.bgColor}`}
//         >
//           <div className="mr-4">{card.icon}</div>
//           <div>
//             <p className="text-gray-700 font-medium">{card.title}</p>
//             <p className="text-2xl font-bold text-gray-900">{card.value}</p>
//           </div>
//         </div>
//       ))}
//     </div>
//   );
// };

// export default SummaryCards;



import React from "react";
import {
  FaProjectDiagram,
  FaFileInvoiceDollar,
  FaCheckCircle,
  FaExclamationCircle,
} from "react-icons/fa";

const SummaryCards = () => {
  const summaryData = [
    {
      title: "Active Projects",
      value: 12,
      icon: <FaProjectDiagram className="text-blue-500 text-4xl" />, // increased icon size
      bgColor: "bg-blue-100",
    },
    {
      title: "Total Invoices",
      value: 45,
      icon: <FaFileInvoiceDollar className="text-yellow-500 text-4xl" />,
      bgColor: "bg-yellow-100",
    },
    {
      title: "Paid Invoices",
      value: 30,
      icon: <FaCheckCircle className="text-green-500 text-4xl" />,
      bgColor: "bg-green-100",
    },
    {
      title: "Pending Invoices",
      value: 15,
      icon: <FaExclamationCircle className="text-red-500 text-4xl" />,
      bgColor: "bg-red-100",
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 p-8">
      {summaryData.map((card, index) => (
        <div
          key={index}
          className={`flex items-center justify-between p-6 rounded-2xl shadow-lg ${card.bgColor} hover:scale-105 transition-transform duration-200`}
          style={{ minHeight: "160px" }} // increased card height
        >
          <div className="mr-4">{card.icon}</div>
          <div>
            <p className="text-gray-700 text-lg font-semibold">{card.title}</p>
            <p className="text-3xl font-bold text-gray-900">{card.value}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default SummaryCards;
