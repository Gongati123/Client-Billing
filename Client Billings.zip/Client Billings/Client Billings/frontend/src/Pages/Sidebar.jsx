// import React from "react";
// import { LayoutDashboard, Users, Briefcase, FileText, BarChart3 } from "lucide-react";
// import { Link } from "react-router-dom";

// const Sidebar = () => {
//   const menu = [
//     { icon: <LayoutDashboard className="w-5 h-5" />, text: "Summary Cards", link: "/super-admin-dashboard/summary" },
//     { icon: <Users />, text: "Clients", link: "/super-admin-dashboard/clients" },
//     { icon: <Briefcase />, text: "Employees", link: "/super-admin-dashboard/employees" },
//     { icon: <FileText />, text: "Invoices", link: "/super-admin-dashboard/invoices" },
//     { icon: <BarChart3 />, text: "Reports", link: "/super-admin-dashboard/reports" },
//   ];

//   return (
//     <div className="w-64 text-black min-h-screen p-6">
//       <h1 className="text-2xl font-bold mb-8 text-center">Dashboard</h1>
//       <ul className="space-y-4">
//         {menu.map((item, idx) => (
//           <li key={idx}>
//             <Link
//               to={item.link || "#"}
//               className="flex items-center gap-3 p-2 rounded-lg hover:bg-blue-200 cursor-pointer"
//             >
//               {item.icon}
//               <span>{item.text}</span>
//             </Link>
//           </li>
//         ))}
//       </ul>
//     </div>
//   );
// };

// export default Sidebar;
