import React, { useState, useEffect } from "react";
import { FaCheckCircle, FaExclamationCircle, FaInfoCircle } from "react-icons/fa";
import notificationsData from "./notificationsData.json"; // ✅ Make sure path is correct

const Notification = () => {
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    // Load notifications from JSON file
    setNotifications(notificationsData);
  }, []);

  return (
    <div className="p-8 bg-gray-50 min-h-screen">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Notifications</h2>

      <div className="bg-white shadow-lg rounded-xl p-6">
        {notifications.length > 0 ? (
          <ul className="divide-y divide-gray-200">
            {notifications.map((note) => (
              <li
                key={note.id}
                className={`flex items-start gap-4 py-4 px-2 rounded-lg transition ${
                  note.read ? "bg-white" : "bg-blue-50"
                } hover:bg-blue-100`}
              >
                {/* Notification Icon */}
                <div className="text-blue-600 mt-1">
                  {note.type === "success" ? (
                    <FaCheckCircle className="text-green-500 text-xl" />
                  ) : note.type === "alert" ? (
                    <FaExclamationCircle className="text-red-500 text-xl" />
                  ) : (
                    <FaInfoCircle className="text-blue-500 text-xl" />
                  )}
                </div>

                {/* Notification Content */}
                <div className="flex-1">
                  <p className="text-gray-800 font-medium">{note.message}</p>
                  <p className="text-sm text-gray-500 mt-1">{note.time}</p>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-gray-500 text-center py-6">No new notifications</p>
        )}
      </div>
    </div>
  );
};

export default Notification;
