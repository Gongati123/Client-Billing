import React, { useState, useEffect } from "react";
import { FaUserPlus, FaEdit, FaTrash, FaSearch } from "react-icons/fa";
import toast from "react-hot-toast";

const TeamLeads = () => {
  const [teamLeads, setTeamLeads] = useState([]);
  const [filteredLeads, setFilteredLeads] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [selectedLead, setSelectedLead] = useState(null);
  const [formData, setFormData] = useState({
    teamLeadId: "",
    email: "",
    role: "",
  });

  // 🔹 Filter team leads based on search
  useEffect(() => {
    const filtered = teamLeads.filter(
      (lead) =>
        lead.teamLeadId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        lead.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        lead.role.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredLeads(filtered);
  }, [searchTerm, teamLeads]);

  // Open Add/Edit Modal
  const handleOpenModal = (lead = null) => {
    if (lead) {
      setEditMode(true);
      setSelectedLead(lead);
      setFormData(lead);
    } else {
      setEditMode(false);
      setSelectedLead(null);
      setFormData({ teamLeadId: "", email: "", role: "" });
    }
    setShowModal(true);
  };

  // Save Lead
  const handleSaveLead = (e) => {
    e.preventDefault();
    if (!formData.teamLeadId || !formData.email || !formData.role) {
      toast.error("⚠️ Please fill all fields!");
      return;
    }

    if (editMode) {
      const updatedLeads = teamLeads.map((lead) =>
        lead.id === selectedLead.id ? { ...formData, id: selectedLead.id } : lead
      );
      setTeamLeads(updatedLeads);
      toast.success("✏️ Team Lead updated!");
    } else {
      setTeamLeads([...teamLeads, { id: Date.now(), ...formData }]);
      toast.success("✅ Team Lead added!");
    }
    setShowModal(false);
    setEditMode(false);
    setSelectedLead(null);
  };

  // Delete Lead
  const handleDeleteLead = (id) => {
    if (window.confirm("Delete this Team Lead?")) {
      const updated = teamLeads.filter((lead) => lead.id !== id);
      setTeamLeads(updated);
      toast.success("🗑️ Team Lead deleted!");
    }
  };

  return (
    <div className="p-4 sm:p-6 bg-gray-50 min-h-screen">
      {/* Header + Search + Add */}
      <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-3">
        <h2 className="text-2xl sm:text-3xl font-bold text-gray-800">Team Leads</h2>
         <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
        {/* Search Bar */}
        <div className="flex items-center w-full sm:w-80 bg-white border border-gray-300 rounded-lg px-3 py-2 shadow-sm">
          <FaSearch className="text-gray-500 mr-2" />
          <input
            type="text"
            placeholder="Search by ID, Email or Role"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full outline-none text-sm bg-transparent"
          />
        </div>

        <button
          onClick={() => handleOpenModal()}
          className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition w-full sm:w-auto"
        >
          <FaUserPlus /> Add Team Lead
        </button>
      </div>
      </div>

      {/* Desktop Table */}
      <div className="hidden md:block overflow-x-auto bg-white shadow-lg rounded-xl">
        <table className="min-w-full border-collapse text-sm sm:text-base">
          <thead>
            <tr className="bg-blue-100 text-gray-800">
              <th className="py-3 px-4 text-center font-semibold">S.No</th>
              <th className="py-3 px-4 text-left font-semibold">TeamLead ID</th>
              <th className="py-3 px-4 text-left font-semibold">Email</th>
              <th className="py-3 px-4 text-left font-semibold">Role</th>
              <th className="py-3 px-4 text-center font-semibold">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredLeads.length > 0 ? (
              filteredLeads.map((lead, index) => (
                <tr key={lead.id} className="border-t hover:bg-blue-50 transition text-gray-700">
                  <td className="py-3 px-4 text-center">{index + 1}</td>
                  <td className="py-3 px-4">{lead.teamLeadId}</td>
                  <td className="py-3 px-4">{lead.email}</td>
                  <td className="py-3 px-4">{lead.role}</td>
                  <td className="py-3 px-4 text-center flex justify-center gap-3">
                    <button onClick={() => handleOpenModal(lead)} className="text-blue-600 hover:text-blue-800">
                      <FaEdit />
                    </button>
                    <button onClick={() => handleDeleteLead(lead.id)} className="text-red-600 hover:text-red-800">
                      <FaTrash />
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" className="text-center py-6 text-gray-500 font-medium">
                  No Team Leads found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Mobile Cards */}
      <div className="md:hidden flex flex-col gap-4">
        {filteredLeads.length > 0 ? (
          filteredLeads.map((lead, index) => (
            <div key={lead.id} className="bg-white p-4 rounded-xl shadow hover:shadow-lg transition">
              <div className="flex justify-between mb-2">
                <span className="font-semibold">#{index + 1}</span>
                <div className="flex gap-2">
                  <button onClick={() => handleOpenModal(lead)} className="text-blue-600 hover:text-blue-800"><FaEdit /></button>
                  <button onClick={() => handleDeleteLead(lead.id)} className="text-red-600 hover:text-red-800"><FaTrash /></button>
                </div>
              </div>
              <div className="space-y-1 text-gray-700">
                <p><strong>ID:</strong> {lead.teamLeadId}</p>
                <p><strong>Email:</strong> {lead.email}</p>
                <p><strong>Role:</strong> {lead.role}</p>
              </div>
            </div>
          ))
        ) : (
          <p className="text-center text-gray-500">No Team Leads found</p>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-40 px-4 z-50">
          <div className="bg-white rounded-xl shadow-lg p-6 w-full max-w-sm sm:max-w-md">
            <h3 className="text-xl font-semibold mb-4 text-gray-800 text-center">
              {editMode ? "Edit Team Lead" : "Add New Team Lead"}
            </h3>
            <form onSubmit={handleSaveLead} className="space-y-3">
              {["teamLeadId", "email", "role"].map((field) => (
                <input
                  key={field}
                  type={field === "email" ? "email" : "text"}
                  placeholder={field.charAt(0).toUpperCase() + field.slice(1)}
                  value={formData[field]}
                  onChange={(e) => setFormData({ ...formData, [field]: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-400 focus:outline-none"
                  required
                />
              ))}
              <div className="flex flex-col sm:flex-row justify-end gap-3 mt-4">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="w-full sm:w-auto bg-gray-400 text-white px-4 py-2 rounded-lg hover:bg-gray-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-full sm:w-auto bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                >
                  {editMode ? "Update" : "Save"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default TeamLeads;
