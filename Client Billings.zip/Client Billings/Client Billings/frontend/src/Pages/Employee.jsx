



// import React, { useState, useEffect } from "react";
// import { FaUserPlus, FaSearch, FaEdit, FaTrash } from "react-icons/fa";
// import employeesData from "./EmployeesData.json";

// const Employees = () => {
//   const [employees, setEmployees] = useState([]);
//   const [search, setSearch] = useState("");
//   const [showModal, setShowModal] = useState(false);
//   const [editMode, setEditMode] = useState(false);
//   const [selectedEmployee, setSelectedEmployee] = useState(null);
//   const [newEmployee, setNewEmployee] = useState({
//     empID: "",
//     name: "",
//     email: "",
//     department: "",
//     designation: "",
//     status: "Active",
//   });

//   useEffect(() => {
//     setEmployees(employeesData);
//   }, []);

//   const handleOpenModal = (employee = null) => {
//     if (employee) {
//       setEditMode(true);
//       setSelectedEmployee(employee);
//       setNewEmployee(employee);
//     } else {
//       setEditMode(false);
//       setNewEmployee({
//         empID: "",
//         name: "",
//         email: "",
//         department: "",
//         designation: "",
//         status: "Active",
//       });
//     }
//     setShowModal(true);
//   };

//   const handleSaveEmployee = (e) => {
//     e.preventDefault();
//     if (!newEmployee.empID || !newEmployee.name || !newEmployee.email) {
//       alert("Please fill all required fields!");
//       return;
//     }

//     if (editMode) {
//       setEmployees((prev) =>
//         prev.map((emp) =>
//           emp.id === selectedEmployee.id ? { ...newEmployee } : emp
//         )
//       );
//       alert("✅ Employee updated successfully!");
//     } else {
//       const newEntry = {
//         id: employees.length > 0 ? employees[employees.length - 1].id + 1 : 1,
//         ...newEmployee,
//       };
//       setEmployees([...employees, newEntry]);
//       alert("✅ Employee added successfully!");
//     }

//     setShowModal(false);
//     setEditMode(false);
//     setSelectedEmployee(null);
//   };

//   const handleDeleteEmployee = (id) => {
//     if (window.confirm("Are you sure you want to delete this employee?")) {
//       setEmployees(employees.filter((emp) => emp.id !== id));
//       alert("🗑️ Employee deleted successfully!");
//     }
//   };

//   const filteredEmployees = employees.filter((emp) =>
//     emp.name.toLowerCase().includes(search.toLowerCase())
//   );

//   return (
//     <div className="p-4 sm:p-6 bg-gray-50 min-h-screen">
//       {/* Header */}
//       <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
//         <h2 className="text-2xl font-bold text-gray-800">Employees</h2>

//         <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
//           <div className="relative w-full sm:w-64">
//             <FaSearch className="absolute top-3 left-3 text-gray-500" />
//             <input
//               type="text"
//               placeholder="Search employee..."
//               value={search}
//               onChange={(e) => setSearch(e.target.value)}
//               className="w-full border border-gray-300 rounded-lg pl-10 pr-3 py-2 focus:ring-2 focus:ring-blue-400 focus:outline-none"
//             />
//           </div>

//           <button
//             onClick={() => handleOpenModal()}
//             className="flex items-center justify-center gap-2 w-full sm:w-auto bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition"
//           >
//             <FaUserPlus />
//             <span className="hidden sm:inline">Add Employee</span>
//           </button>
//         </div>
//       </div>

//       {/* TABLE FOR DESKTOP */}
//       <div className="hidden md:block overflow-x-auto bg-white shadow-lg rounded-xl">
//         <table className="min-w-full border-collapse text-sm sm:text-base">
//           <thead>
//             <tr className="bg-blue-100 text-gray-800">
//               <th className="py-3 px-4 text-left font-semibold">S.No</th>
//               <th className="py-3 px-4 text-left font-semibold">Emp ID</th>
//               {/* <th className="py-3 px-4 text-left font-semibold">Name</th> */}
//               <th className="py-3 px-4 text-left font-semibold">Email</th>
//               <th className="py-3 px-4 text-left font-semibold">Role</th>
//               <th className="py-3 px-4 text-left font-semibold">Designation</th>
//               <th className="py-3 px-4 text-center font-semibold">Status</th>
//               <th className="py-3 px-4 text-center font-semibold">Action</th>
//             </tr>
//           </thead>

//           <tbody>
//             {filteredEmployees.length > 0 ? (
//               filteredEmployees.map((emp, index) => (
//                 <tr
//                   key={emp.id}
//                   className="border-t hover:bg-blue-50 transition text-gray-700"
//                 >
//                   <td className="py-3 px-4 text-center">{index + 1}</td>
//                   <td className="py-3 px-4">{emp.empID}</td>
//                   {/* <td className="py-3 px-4">{emp.name}</td> */}
//                   <td className="py-3 px-4">{emp.email}</td>
//                   <td className="py-3 px-4">{emp.role}</td>
//                   <td className="py-3 px-4">{emp.designation}</td>
//                   <td
//                     className={`py-3 px-4 text-center font-semibold ${
//                       emp.status === "Active"
//                         ? "text-green-600"
//                         : "text-red-600"
//                     }`}
//                   >
//                     {emp.status}
//                   </td>
//                   <td className="py-3 px-4 text-center flex justify-center gap-3">
//                     <button
//                       onClick={() => handleOpenModal(emp)}
//                       className="text-blue-600 hover:text-blue-800"
//                     >
//                       <FaEdit size={16} />
//                     </button>
//                     <button
//                       onClick={() => handleDeleteEmployee(emp.id)}
//                       className="text-red-600 hover:text-red-800"
//                     >
//                       <FaTrash size={16} />
//                     </button>
//                   </td>
//                 </tr>
//               ))
//             ) : (
//               <tr>
//                 <td
//                   colSpan="8"
//                   className="text-center py-6 text-gray-500 font-medium"
//                 >
//                   No employees found
//                 </td>
//               </tr>
//             )}
//           </tbody>
//         </table>
//       </div>

//       {/* CARD VIEW FOR MOBILE */}
//       <div className="md:hidden grid grid-cols-1 gap-4">
//         {filteredEmployees.length > 0 ? (
//           filteredEmployees.map((emp, index) => (
//             <div
//               key={emp.id}
//               className="bg-white shadow-md rounded-lg p-4 border border-gray-200"
//             >
//               <div className="flex justify-between items-center mb-2">
//                 {/* <h3 className="font-semibold text-lg text-gray-800">
//                   {emp.name}
//                 </h3> */}
//                 <span
//                   className={`text-sm font-semibold ${
//                     emp.status === "Active"
//                       ? "text-green-600"
//                       : "text-red-600"
//                   }`}
//                 >
//                   {emp.status}
//                 </span>
//               </div>
//               <p className="text-sm text-gray-700">
//                 <strong>ID:</strong> {emp.empID}
//               </p>
//               <p className="text-sm text-gray-700">
//                 <strong>Email:</strong> {emp.email}
//               </p>
//               <p className="text-sm text-gray-700">
//                 <strong>Role:</strong> {emp.role}
//               </p>
//               <p className="text-sm text-gray-700 mb-2">
//                 <strong>Designation:</strong> {emp.designation}
//               </p>
//               <div className="flex justify-end gap-3">
//                 <button
//                   onClick={() => handleOpenModal(emp)}
//                   className="text-blue-600 hover:text-blue-800"
//                 >
//                   <FaEdit />
//                 </button>
//                 <button
//                   onClick={() => handleDeleteEmployee(emp.id)}
//                   className="text-red-600 hover:text-red-800"
//                 >
//                   <FaTrash />
//                 </button>
//               </div>
//             </div>
//           ))
//         ) : (
//           <p className="text-center text-gray-500">No employees found</p>
//         )}
//       </div>

//       {/* Modal */}
//       {showModal && (
//         <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-40 z-50 px-4">
//           <div className="bg-white rounded-xl shadow-lg p-6 w-full max-w-md">
//             <h3 className="text-xl font-semibold mb-4 text-gray-800 text-center">
//               {editMode ? "Edit Employee" : "Add New Employee"}
//             </h3>

//             <form onSubmit={handleSaveEmployee} className="space-y-4">
//               {["empID", "name", "email", "department", "designation"].map(
//                 (field, i) => (
//                   <input
//                     key={i}
//                     type={field === "email" ? "email" : "text"}
//                     placeholder={field.charAt(0).toUpperCase() + field.slice(1)}
//                     value={newEmployee[field]}
//                     onChange={(e) =>
//                       setNewEmployee({
//                         ...newEmployee,
//                         [field]: e.target.value,
//                       })
//                     }
//                     className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-400 focus:outline-none"
//                     required
//                   />
//                 )
//               )}

//               <select
//                 value={newEmployee.status}
//                 onChange={(e) =>
//                   setNewEmployee({ ...newEmployee, status: e.target.value })
//                 }
//                 className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-400 focus:outline-none"
//               >
//                 <option>Active</option>
//                 <option>Inactive</option>
//               </select>

//               <div className="flex flex-col sm:flex-row justify-end gap-3 mt-4">
//                 <button
//                   type="button"
//                   onClick={() => setShowModal(false)}
//                   className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 w-full sm:w-auto"
//                 >
//                   Cancel
//                 </button>
//                 <button
//                   type="submit"
//                   className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 w-full sm:w-auto"
//                 >
//                   {editMode ? "Update" : "Save"}
//                 </button>
//               </div>
//             </form>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default Employees;


import React, { useState, useEffect } from "react";
import { FaUserPlus, FaSearch, FaEdit, FaTrash } from "react-icons/fa";
import employeesData from "./EmployeesData.json";
import toast from "react-hot-toast"; // ✅ Import toast

const Employees = () => {
  const [employees, setEmployees] = useState([]);
  const [search, setSearch] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [newEmployee, setNewEmployee] = useState({
    empID: "",
    name: "",
    email: "",
    department: "",
    designation: "",
    role: "",
    status: "Active",
  });

  useEffect(() => {
    setEmployees(employeesData);
  }, []);

  const handleOpenModal = (employee = null) => {
    if (employee) {
      setEditMode(true);
      setSelectedEmployee(employee);
      setNewEmployee(employee);
    } else {
      setEditMode(false);
      setNewEmployee({
        empID: "",
        name: "",
        email: "",
      
        designation: "",
        role: "",
        status: "Active",
      });
    }
    setShowModal(true);
  };

  const handleSaveEmployee = (e) => {
    e.preventDefault();

    if (!newEmployee.empID || !newEmployee.name || !newEmployee.email || !newEmployee.role) {
      toast.error("⚠️ Please fill all required fields!");
      return;
    }

    if (editMode) {
      setEmployees((prev) =>
        prev.map((emp) =>
          emp.id === selectedEmployee.id ? { ...newEmployee } : emp
        )
      );
      toast.success("✏️ Employee updated successfully!");
    } else {
      const newEntry = {
        id: employees.length > 0 ? employees[employees.length - 1].id + 1 : 1,
        ...newEmployee,
      };
      setEmployees([...employees, newEntry]);
      toast.success("✅ Employee added successfully!");
    }

    setShowModal(false);
    setEditMode(false);
    setSelectedEmployee(null);
  };

  const handleDeleteEmployee = (id) => {
    // if (window.confirm("Are you sure you want to delete this employee?")) {
      setEmployees(employees.filter((emp) => emp.id !== id));
      toast.success("🗑️ Employee deleted successfully!");
    // }
  };

  const filteredEmployees = employees.filter((emp) =>
    emp.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-4 sm:p-6 bg-gray-50 min-h-screen">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
        <h2 className="text-2xl font-bold text-gray-800">Employees</h2>

        <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
          <div className="relative w-full sm:w-64">
            <FaSearch className="absolute top-3 left-3 text-gray-500" />
            <input
              type="text"
              placeholder="Search employee..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full border border-gray-300 rounded-lg pl-10 pr-3 py-2 focus:ring-2 focus:ring-blue-400 focus:outline-none"
            />
          </div>

          <button
            onClick={() => handleOpenModal()}
            className="flex items-center justify-center gap-2 w-full sm:w-auto bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition"
          >
            <FaUserPlus />
            <span className="hidden sm:inline">Add Employee</span>
          </button>
        </div>
      </div>

      {/* Desktop Table */}
      <div className="hidden md:block overflow-x-auto bg-white shadow-lg rounded-xl">
        <table className="min-w-full border-collapse text-sm sm:text-base">
          <thead>
            <tr className="bg-blue-100 text-gray-800">
              <th className="py-3 px-4 text-left font-semibold">S.No</th>
              <th className="py-3 px-4 text-left font-semibold">Emp ID</th>
              <th className="py-3 px-4 text-left font-semibold">Email</th>
              <th className="py-3 px-4 text-left font-semibold">Role</th>
              <th className="py-3 px-4 text-left font-semibold">Designation</th>
              <th className="py-3 px-4 text-center font-semibold">Status</th>
              <th className="py-3 px-4 text-center font-semibold">Action</th>
            </tr>
          </thead>
          <tbody>
            {filteredEmployees.length > 0 ? (
              filteredEmployees.map((emp, index) => (
                <tr key={emp.id} className="border-t hover:bg-blue-50 transition text-gray-700">
                  <td className="py-3 px-4 text-center">{index + 1}</td>
                  <td className="py-3 px-4">{emp.empID}</td>
                  <td className="py-3 px-4">{emp.email}</td>
                  <td className="py-3 px-4">{emp.role}</td>
                  <td className="py-3 px-4">{emp.designation}</td>
                  <td className={`py-3 px-4 text-center font-semibold ${emp.status === "Active" ? "text-green-600" : "text-red-600"}`}>
                    {emp.status}
                  </td>
                  <td className="py-3 px-4 text-center flex justify-center gap-3">
                    <button onClick={() => handleOpenModal(emp)} className="text-blue-600 hover:text-blue-800">
                      <FaEdit size={16} />
                    </button>
                    <button onClick={() => handleDeleteEmployee(emp.id)} className="text-red-600 hover:text-red-800">
                      <FaTrash size={16} />
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="7" className="text-center py-6 text-gray-500 font-medium">
                  No employees found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Mobile Cards */}
      <div className="md:hidden grid grid-cols-1 gap-4">
        {filteredEmployees.length > 0 ? (
          filteredEmployees.map((emp, index) => (
            <div key={emp.id} className="bg-white shadow-md rounded-lg p-4 border border-gray-200">
              <div className="flex justify-between items-center mb-2">
                <span className={`text-sm font-semibold ${emp.status === "Active" ? "text-green-600" : "text-red-600"}`}>{emp.status}</span>
              </div>
              <p className="text-sm text-gray-700"><strong>ID:</strong> {emp.empID}</p>
              <p className="text-sm text-gray-700"><strong>Email:</strong> {emp.email}</p>
              <p className="text-sm text-gray-700"><strong>Role:</strong> {emp.role}</p>
              <p className="text-sm text-gray-700 mb-2"><strong>Designation:</strong> {emp.designation}</p>
              <div className="flex justify-end gap-3">
                <button onClick={() => handleOpenModal(emp)} className="text-blue-600 hover:text-blue-800"><FaEdit /></button>
                <button onClick={() => handleDeleteEmployee(emp.id)} className="text-red-600 hover:text-red-800"><FaTrash /></button>
              </div>
            </div>
          ))
        ) : (
          <p className="text-center text-gray-500">No employees found</p>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-40 z-50 px-4">
          <div className="bg-white rounded-xl shadow-lg p-6 w-full max-w-md">
            <h3 className="text-xl font-semibold mb-4 text-gray-800 text-center">
              {editMode ? "Edit Employee" : "Add New Employee"}
            </h3>
            <div className="relative w-full sm:w-64">
                               <FaSearch className="absolute top-3 left-3 text-gray-500" />
                               <input
                                 type="text"
                                 placeholder="Search employee..."
                                 value={search}
                                 onChange={(e) => setSearch(e.target.value)}
                                 className="w-full border border-gray-300 rounded-lg pl-10 pr-3 py-2 focus:ring-2 focus:ring-blue-400 focus:outline-none"
                               />
            </div>

            <form onSubmit={handleSaveEmployee} className="space-y-4">
              {["empID", "name", "email", "name", "designation", "role"].map((field, i) => (
                <input
                  key={i}
                  type={field === "email" ? "email" : "text"}
                  placeholder={field.charAt(0).toUpperCase() + field.slice(1)}
                  value={newEmployee[field]}
                  onChange={(e) => setNewEmployee({ ...newEmployee, [field]: e.target.value })}
                  className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-400 focus:outline-none"
                  required
                />
              ))}

              <select status
                value={newEmployee.status}
                onChange={(e) => setNewEmployee({ ...newEmployee, status: e.target.value })}
                className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-400 focus:outline-none"
              >
                <option>Active</option>
                <option>Inactive</option>
              </select>

              <div className="flex flex-col sm:flex-row justify-end gap-3 mt-4">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 w-full sm:w-auto"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 w-full sm:w-auto"
                >
                  {editMode ? "Update" : "Save"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Employees;
